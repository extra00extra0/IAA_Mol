import json
import ast
from collections import defaultdict

K = 0.8


def parse_substructure_field(substructure_str):
    """
    原始字段：
    "{'[3*]OC', '[16*]c1ccccc1', '[7*]C1C(=O)NN([10*])C1=O', ...}"
    """
    if not substructure_str:
        return []

    substructure_str = substructure_str.strip()

    try:
        substructure_str = substructure_str.replace('\\N','\\\\N')
        parsed = ast.literal_eval(substructure_str)
    except Exception:
        if substructure_str.startswith("{") and substructure_str.endswith("}"):
            inner = substructure_str[1:-1]
            try:
                parsed = ast.literal_eval("[" + inner + "]")
            except Exception:
                print("skip!")
                return []
        else:
            print("skip!")
            return []
            
    if isinstance(parsed, (set, list, tuple)):
        return list(parsed)
    elif isinstance(parsed, str):
        return [parsed]
    else:
        return []


def build_substructure_statistics(train_samples):
    stats = defaultdict(lambda: {"a": 0, "b": 0, "c": 0})

    for sample in train_samples:
        cls_label = sample.get("cls_label")
        substructure_str = sample.get("substructure")

        substructures = parse_substructure_field(substructure_str)
        if not substructures:
            continue

        for sub in substructures:
            sub = sub.strip()
            if not sub:
                continue

            stats[sub]["a"] += 1
            if cls_label == 0:
                stats[sub]["b"] += 1
            elif cls_label == 1:
                stats[sub]["c"] += 1

    return stats


def build_substructure_dataset(stats, k=K):
    """
      - smiles: 子结构字符串
      - label: [b/a, c/a]
      - confidence: 1 - (1/a)**k
    返回：list[dict]
    """
    new_samples = []

    for sub, cnt in stats.items():
        a = cnt["a"]
        b = cnt["b"]
        c = cnt["c"]

        if a <= 0:
            continue

        p0 = b / a
        p1 = c / a

        confidence = 1.0 - (1.0 / a) ** k

        new_samples.append(
            {
                "smiles": sub,
                "label": [p0, p1],
                "confidence": confidence,
            }
        )

    return new_samples


def main(input_json_path, output_json_path, k=K):
    with open(input_json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    train_samples = data.get("split", {}).get("train", [])
    if not isinstance(train_samples, list):
        raise ValueError("'split.train' 应该是一个列表")

    stats = build_substructure_statistics(train_samples)

    substructure_dataset = build_substructure_dataset(stats, k=k)

    output_obj = {
        "k": k,
        "samples": substructure_dataset,
    }

    with open(output_json_path, "w", encoding="utf-8") as f:
        json.dump(output_obj, f, ensure_ascii=False, indent=4)


if __name__ == "__main__":
    input_path = "lbap_refined_ec50_assay_brics.json"
    output_path = "lbap_refined_ec50_assay_brics_substructures.json"
    main(input_path, output_path)

      