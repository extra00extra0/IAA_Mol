# Copyright (C) 2021 THL A29 Limited, a Tencent company.  All rights reserved.
from .irm_optimizer_hook import IRMOptimizerHook
