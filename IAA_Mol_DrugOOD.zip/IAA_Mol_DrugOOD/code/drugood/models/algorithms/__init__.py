# Copyright (C) 2021 THL A29 Limited, a Tencent company.
# All rights reserved.
from .coral import CORAL
from .dann import DANN
from .erm import ERM
from .groupdro import GroupDRO
from .irm import IRM
from .mixup import MixUp
