# !/bin/bash
# python main.py --dist_w 0 --seed 1 --exp_id ec50_assay_seed_0
# python main.py --dist_w 0 --seed 1 --exp_id ec50_assay_seed_1
# python main.py --dist_w 0 --seed 2 --exp_id ec50_assay_seed_2 
# python main.py --dist_w 0 --seed 3 --exp_id ec50_assay_seed_3
# python main.py --dist_w 0 --seed 4 --exp_id ec50_assay_seed_4 


# python main.py --dataset drugood_lbap_core_ec50_scaffold --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_scaffold_brics_substructures.json --batch_size 16 --emb_dim 64 --cau_mix_w 0 --simsiam_w 0 -c_in feat --vrex_w 0 --seed 0 --exp_id ec50_scaffold_seed_0
# python main.py --dataset drugood_lbap_core_ec50_scaffold --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_scaffold_brics_substructures.json --batch_size 16 --emb_dim 64 --cau_mix_w 0 --simsiam_w 0 -c_in feat --vrex_w 0 --seed 1 --exp_id ec50_scaffold_seed_1
# python main.py --dataset drugood_lbap_core_ec50_scaffold --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_scaffold_brics_substructures.json --batch_size 16 --emb_dim 64 --cau_mix_w 0 --simsiam_w 0 -c_in feat --vrex_w 0 --seed 2 --exp_id ec50_scaffold_seed_2
# python main.py --dataset drugood_lbap_core_ec50_scaffold --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_scaffold_brics_substructures.json --batch_size 16 --emb_dim 64 --cau_mix_w 0 --simsiam_w 0 -c_in feat --vrex_w 0 --seed 3 --exp_id ec50_scaffold_seed_3
# python main.py --dataset drugood_lbap_core_ec50_scaffold --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_scaffold_brics_substructures.json --batch_size 16 --emb_dim 64 --cau_mix_w 0 --simsiam_w 0 -c_in feat --vrex_w 0 --seed 4 --exp_id ec50_scaffold_seed_4


# python main.py --dataset drugood_lbap_core_ec50_size --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_size_brics_substructures.json -c_in feat --emb_dim 64 --shuf_after_mix 1 --num_layers 3 --dropout 0.5 --seed 0 --exp_id ec50_size_seed_0
# python main.py --dataset drugood_lbap_core_ec50_size --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_size_brics_substructures.json -c_in feat --emb_dim 64 --shuf_after_mix 1 --num_layers 3 --dropout 0.5 --seed 1 --exp_id ec50_size_seed_1
# python main.py --dataset drugood_lbap_core_ec50_size --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_size_brics_substructures.json -c_in feat --emb_dim 64 --shuf_after_mix 1 --num_layers 3 --dropout 0.5 --seed 2 --exp_id ec50_size_seed_2
# python main.py --dataset drugood_lbap_core_ec50_size --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_size_brics_substructures.json -c_in feat --emb_dim 64 --shuf_after_mix 1 --num_layers 3 --dropout 0.5 --seed 3 --exp_id ec50_size_seed_3
# python main.py --dataset drugood_lbap_core_ec50_size --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_size_brics_substructures.json -c_in feat --emb_dim 64 --shuf_after_mix 1 --num_layers 3 --dropout 0.5 --seed 4 --exp_id ec50_size_seed_4


# python main.py --dataset drugood_lbap_core_ic50_assay --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_assay_brics_substructures.json -c_in feat --emb_dim 128 --num_layers 3 --dist 0 --seed 0 --exp_id ic50_assay_layers_3_d0_0
# python main.py --dataset drugood_lbap_core_ic50_assay --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_assay_brics_substructures.json -c_in feat --emb_dim 128 --num_layers 3 --dist 0 --seed 1 --exp_id ic50_assay_layers_3_d0_1
# python main.py --dataset drugood_lbap_core_ic50_assay --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_assay_brics_substructures.json -c_in feat --emb_dim 128 --num_layers 3 --dist 0 --seed 2 --exp_id ic50_assay_layers_3_d0_2
# python main.py --dataset drugood_lbap_core_ic50_assay --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_assay_brics_substructures.json -c_in feat --emb_dim 128 --num_layers 3 --dist 0 --seed 3 --exp_id ic50_assay_layers_3_d0_3
# python main.py --dataset drugood_lbap_core_ic50_assay --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_assay_brics_substructures.json -c_in feat --emb_dim 128 --num_layers 3 --dist 0 --seed 4 --exp_id ic50_assay_layers_3_d0_4


# python main.py --dataset drugood_lbap_core_ic50_scaffold --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_scaffold_brics_substructures.json --cau_mix_w 0 --seed 0 --exp_id ic50_scaffold_seed_0
# python main.py --dataset drugood_lbap_core_ic50_scaffold --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_scaffold_brics_substructures.json --cau_mix_w 0 --seed 1 --exp_id ic50_scaffold_seed_1
# python main.py --dataset drugood_lbap_core_ic50_scaffold --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_scaffold_brics_substructures.json --cau_mix_w 0 --seed 2 --exp_id ic50_scaffold_seed_2
# python main.py --dataset drugood_lbap_core_ic50_scaffold --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_scaffold_brics_substructures.json --cau_mix_w 0 --seed 3 --exp_id ic50_scaffold_seed_3
# python main.py --dataset drugood_lbap_core_ic50_scaffold --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_scaffold_brics_substructures.json --cau_mix_w 0 --seed 4 --exp_id ic50_scaffold_seed_4


python main.py --dataset drugood_lbap_core_ic50_size --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_size_brics_substructures.json -c_in feat --emb_dim 64 --dist 0 --num_layers 3 --seed 0 --exp_id ic50_size_seed_0
python main.py --dataset drugood_lbap_core_ic50_size --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_size_brics_substructures.json -c_in feat --emb_dim 64 --dist 0 --num_layers 3 --seed 1 --exp_id ic50_size_seed_1
python main.py --dataset drugood_lbap_core_ic50_size --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_size_brics_substructures.json -c_in feat --emb_dim 64 --dist 0 --num_layers 3 --seed 2 --exp_id ic50_size_seed_2
python main.py --dataset drugood_lbap_core_ic50_size --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_size_brics_substructures.json -c_in feat --emb_dim 64 --dist 0 --num_layers 3 --seed 3 --exp_id ic50_size_seed_3
python main.py --dataset drugood_lbap_core_ic50_size --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_size_brics_substructures.json -c_in feat --emb_dim 64 --dist 0 --num_layers 3 --seed 4 --exp_id ic50_size_seed_4






