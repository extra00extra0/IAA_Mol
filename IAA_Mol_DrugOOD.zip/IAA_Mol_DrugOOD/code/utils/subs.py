import torch
from torch_geometric.data import Data
import json

def load_sub_info(json_path):
    """
    {
      "k": 0.8,
      "samples": [
        {
          "smiles": "...",
          "label": [p0, p1],
          "confidence": c
        },
        ...
      ]
    }
    return dict[smiles] = (label_list, confidence)
    """
    with open(json_path, 'r') as f:
        data = json.load(f)

    table = {}
    for item in data["samples"]:
        smi = item["smiles"]
        label = item["label"]          
        conf = item["confidence"]      
        table[smi] = (label, conf)
    return table

def dgl_to_pyg(dgl_graph):
    if dgl_graph is None:
        return None
    x = dgl_graph.ndata['x']            

    src, dst = dgl_graph.edges()     
    edge_index = torch.stack([src, dst], dim=0)

    edge_attr = dgl_graph.edata['x']    

    pyg_data = Data(
        x=x,
        edge_index=edge_index,
        edge_attr=edge_attr
    )

    return pyg_data