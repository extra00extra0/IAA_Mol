import os
import numpy as np
import torch
import torch.nn.functional as F
from torch_geometric.nn import global_mean_pool
from ogb.graphproppred import Evaluator
from tqdm import tqdm

def concrete_sample(att_log_logit, temp):
    random_noise = torch.empty_like(att_log_logit).uniform_(1e-10, 1 - 1e-10)
    random_noise = torch.log(random_noise) - torch.log(1.0 - random_noise)
    att_bern = ((att_log_logit + random_noise) / temp).sigmoid()
    return att_bern
    
def pretrain_gnn_eval(gnn, mlp, cls, loader, evaluator, device, temp):
    y_true=[]
    y_pred=[]
    for batch in loader:
        with torch.no_grad():
            batch = batch.to(device)
            batch.x = batch.x.float()
            batch.y = batch.y.reshape(-1)
            is_labeled = batch.y == batch.y
            node_feat = gnn(batch)
            row, col = batch.edge_index
            edge_feat = torch.cat([node_feat[row], node_feat[col]], dim=1)
            score_on_edge = mlp(edge_feat)
            score_on_edge = concrete_sample(score_on_edge, temp)
            cau_edge_feat = score_on_edge * edge_feat
            cau_graph_feat = global_mean_pool(cau_edge_feat, batch.batch[row])
            pred = cls(cau_graph_feat)
            pred = F.softmax(pred, dim=-1)[:, 1].unsqueeze(-1)
            y_true.append(batch.y.view(-1, 1).detach().cpu())
            y_pred.append(pred.detach().view(-1, 1).cpu())
    y_true = torch.cat(y_true, dim=0).numpy()
    y_pred = torch.cat(y_pred, dim=0).numpy()
    eval_metric='rocauc'
    input_dict = {"y_true": y_true, "y_pred": y_pred}
    res_metric = evaluator.eval(input_dict)[eval_metric]
    return res_metric

def pretrain_gnn(gnn, mlp, cls, args, train_loader, valid_loader, test_loader, exp_dir, device, criterion):
    model_optimizer = torch.optim.Adam(list(gnn.parameters())+list(mlp.parameters())+list(cls.parameters()), lr=args.lr)
    last_train_auc, last_test_auc, last_valid_auc = 0, 0, 0
    for epoch in range(args.pretrain_epoch):
        for model in [gnn, mlp, cls]:
            model.train()
        num_batch = (len(train_loader.dataset) // args.batch_size) + int(
                (len(train_loader.dataset) % args.batch_size) > 0)
        for step, graph in tqdm(enumerate(train_loader), total=num_batch, desc=f"Pretrain_gnn_epoch [{epoch}] >>  ", disable=args.no_tqdm, ncols=60):
            graph.to(device)
            graph.x = graph.x.float().to(device)
            graph.y = graph.y.reshape(-1)
            is_labeled = graph.y == graph.y
            node_feat = gnn(graph)
            row, col = graph.edge_index
            edge_feat = torch.cat([node_feat[row], node_feat[col]], dim=1)
            score_on_edge = mlp(edge_feat)
            score_on_edge = concrete_sample(score_on_edge, args.temp)
            cau_edge_feat = score_on_edge * edge_feat
            cau_graph_feat = global_mean_pool(cau_edge_feat, graph.batch[row])
            pred = cls(cau_graph_feat)
            pred_loss = criterion(pred[is_labeled], graph.y[is_labeled],reduction='none').mean()
            model_optimizer.zero_grad()
            pred_loss.backward()
            model_optimizer.step()
        for model in [gnn, mlp, cls]:
            model.eval()
        evaluator = Evaluator('ogbg-molhiv')
        train_auc = pretrain_gnn_eval(gnn, mlp, cls, train_loader, evaluator, device, args.temp)
        valid_auc = pretrain_gnn_eval(gnn, mlp, cls, valid_loader, evaluator, device, args.temp)
        test_auc = pretrain_gnn_eval(gnn, mlp, cls, test_loader, evaluator, device, args.temp)
        if valid_auc > last_valid_auc:
            last_train_auc = train_auc
            last_valid_auc = valid_auc
            last_test_auc = test_auc
            torch.save(gnn.state_dict(), os.path.join(exp_dir, "gnn.pth"))
            torch.save(mlp.state_dict(), os.path.join(exp_dir, "mlp.pth"))
        print("      [{:3d}/{:d}]".format(epoch, args.epoch) +
                        "\n       train_ACC: {:.4f} / {:.4f}"
                        "\n       valid_ACC: {:.4f} / {:.4f}"
                        "\n       tests_ACC: {:.4f} / {:.4f}\n".format(
                            train_auc, last_train_auc,
                            valid_auc, last_valid_auc,
                            test_auc, last_test_auc))
             
             
def pretrain_cls_eval(model, loader, evaluator, device, c_in="raw"):
    y_true=[]
    y_pred=[]
    for batch in loader:
        with torch.no_grad():
            batch = batch.to(device)
            batch.x = batch.x.float()
            batch.y = batch.y.reshape(-1)
            is_labeled = batch.y == batch.y
#            pred = model(batch)
            if c_in=="raw":
                pred = model(batch)
            else:
                pred = model.get_eval_pred(batch)
            pred = F.softmax(pred, dim=-1)[:, 1].unsqueeze(-1)
            y_true.append(batch.y.view(-1, 1).detach().cpu())
            y_pred.append(pred.detach().view(-1, 1).cpu())
    y_true = torch.cat(y_true, dim=0).numpy()
    y_pred = torch.cat(y_pred, dim=0).numpy()
    eval_metric='rocauc'
    input_dict = {"y_true": y_true, "y_pred": y_pred}
    res_metric = evaluator.eval(input_dict)[eval_metric]
    return res_metric
    
                            
def pretrain_cls(model, args, train_loader, valid_loader, test_loader, exp_dir, device, criterion, c_in="raw"):
    model_optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    last_train_auc, last_test_auc, last_valid_auc = 0, 0, 0
    for epoch in range(args.pretrain_epoch):
        model.train()
        num_batch = (len(train_loader.dataset) // args.batch_size) + int(
                (len(train_loader.dataset) % args.batch_size) > 0)
        for step, graph in tqdm(enumerate(train_loader), total=num_batch, desc=f"Pretrain_gnn_epoch [{epoch}] >>  ", disable=args.no_tqdm, ncols=60):
            graph.to(device)
            graph.x = graph.x.float().to(device)
            graph.y = graph.y.reshape(-1)
            is_labeled = graph.y == graph.y
            if c_in=="raw":
                pred = model(graph)
            else:
                pred = model.get_eval_pred(graph)
            pred_loss = criterion(pred[is_labeled], graph.y[is_labeled],reduction='none').mean()
            model_optimizer.zero_grad()
            pred_loss.backward()
            model_optimizer.step()
        model.eval()
        evaluator = Evaluator('ogbg-molhiv')
        train_auc = pretrain_cls_eval(model,train_loader, evaluator, device, c_in=c_in)
        valid_auc = pretrain_cls_eval(model, valid_loader, evaluator, device, c_in=c_in)
        test_auc = pretrain_cls_eval(model, test_loader, evaluator, device, c_in=c_in)
        if valid_auc > last_valid_auc:
            last_train_auc = train_auc
            last_valid_auc = valid_auc
            last_test_auc = test_auc
            torch.save(model.state_dict(), os.path.join(exp_dir, "cls.pth"))
        print("      [{:3d}/{:d}]".format(epoch, args.epoch) +
                        "\n       train_ACC: {:.4f} / {:.4f}"
                        "\n       valid_ACC: {:.4f} / {:.4f}"
                        "\n       tests_ACC: {:.4f} / {:.4f}\n".format(
                            train_auc, last_train_auc,
                            valid_auc, last_valid_auc,
                            test_auc, last_test_auc))
        
