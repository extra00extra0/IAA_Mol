import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch_geometric.data.batch as DataBatch
from torch_geometric.nn import (ASAPooling, global_add_pool, global_max_pool,
                                global_mean_pool)
from utils.get_subgraph import relabel, split_batch
from utils.mask import clear_masks, set_masks ,my_clear_masks,my_set_masks

from models.conv import GNN_node, GNN_node_Virtualnode
from models.gnn import GNN, LeGNN
from collections import  defaultdict

from torch_geometric.data import Batch, Data
import random
from utils.subs import dgl_to_pyg
from drugood.utils.smile_to_dgl import smile2graph


class iaa_mol(nn.Module):

    def __init__(self,
                 input_dim,
                 out_dim,
                 edge_dim=-1,
                 emb_dim=300,
                 num_layers=5,
                 ratio=0.5,
                 gnn_type='gin',
                 virtual_node=True,
                 residual=False,
                 drop_ratio=0.5,
                 JK="last",
                 graph_pooling="mean",
                 c_dim=-1,
                 c_in="raw",
                 c_rep="rep",
                 c_pool="add",
                 s_rep="rep",
                 sigma_len=3,
                 eps=-1):
        super(iaa_mol, self).__init__()
        ### GNN to generate node embeddings
        if gnn_type.lower() == "le":
            self.gnn_encoder = LeGNN(in_channels=input_dim,
                                     hid_channels=emb_dim,
                                     num_layer=num_layers,
                                     drop_ratio=drop_ratio,
                                     num_classes=out_dim,
                                     edge_dim=edge_dim)
        else:
            if virtual_node:
                self.gnn_encoder = GNN_node_Virtualnode(num_layers,
                                                        emb_dim,
                                                        input_dim=input_dim,
                                                        JK=JK,
                                                        drop_ratio=drop_ratio,
                                                        residual=residual,
                                                        gnn_type=gnn_type,
                                                        edge_dim=edge_dim)
            else:
                self.gnn_encoder = GNN_node(num_layers,
                                            emb_dim,
                                            input_dim=input_dim,
                                            JK=JK,
                                            drop_ratio=drop_ratio,
                                            residual=residual,
                                            gnn_type=gnn_type,
                                            edge_dim=edge_dim)
        self.ratio = ratio

        self.edge_att = nn.Sequential(nn.Linear(emb_dim * 2, emb_dim * 4), nn.ReLU(), nn.LayerNorm(emb_dim * 4), nn.Linear(emb_dim * 4, 1),nn.Sigmoid())
        self.s_rep = s_rep
        self.c_rep = c_rep
        self.c_pool = c_pool

        # predictor based on the decoupled subgraph
        self.pred_head = "spu" if s_rep.lower() == "conv" else "inv"
        # self.c_dim = emb_dim if c_dim < 0 else c_dim
        self.c_dim = emb_dim
        self.c_in = c_in
        self.c_input_dim = input_dim if c_in.lower() == "raw" else emb_dim
        self.classifier = GNN(gnn_type=gnn_type,
                              input_dim=self.c_input_dim,
                              num_class=out_dim,
                              num_layer=num_layers,
                              emb_dim=self.c_dim,
                              drop_ratio=drop_ratio,
                              virtual_node=virtual_node,
                              graph_pooling=graph_pooling,
                              residual=residual,
                              JK=JK,
                              pred_head=self.pred_head,
                              edge_dim=edge_dim)
                              


        self.log_sigmas = nn.Parameter(torch.zeros(sigma_len))
        self.log_sigmas.requires_grad_(True)
        
        self.projector = nn.Sequential(nn.Linear(emb_dim, emb_dim * 2), nn.ReLU(), nn.LayerNorm(emb_dim*2), nn.Linear(emb_dim * 2, emb_dim))
        self.predictor = nn.Sequential(nn.Linear(emb_dim, emb_dim // 2), nn.ReLU(), nn.LayerNorm(emb_dim//2), nn.Linear(emb_dim // 2, emb_dim))
        self.sub_mp = nn.Linear(emb_dim*2, 1)
        self.eps = eps
        
    def shuffle_per_g(self, x, edge_index, edge_attr, batch):
        device = x.device
        perm_chunks = []
        for g in batch.unique():
            node_idx = (batch == g).nonzero(as_tuple=False).view(-1)
            shuffled = node_idx[torch.randperm(node_idx.numel(), device=device)]
            perm_chunks.append(shuffled)

        perm_all = torch.cat(perm_chunks, dim=0)

        new_x = x[perm_all]
        new_batch = batch[perm_all]

        inv_perm = torch.empty_like(perm_all)
        inv_perm[perm_all] = torch.arange(perm_all.numel(), device=device)
        new_edge_index = inv_perm[edge_index]

        return new_x, new_edge_index, edge_attr, new_batch
        
    def cosine_sim(self, a, b):
        return (a * b).sum(dim=1)

    def get_simsiam_loss(self, h_1, h_2):
        z_1 = self.projector(h_1)
        z_2 = self.projector(h_2)
        p_1 = self.predictor(z_1)
        p_2 = self.predictor(z_2)
        
        z_1 = F.normalize(z_1, dim=1)
        z_2 = F.normalize(z_2, dim=1)
        p_1 = F.normalize(p_1, dim=1)
        p_2 = F.normalize(p_2, dim=1)


        loss_1 = -self.cosine_sim(p_1, z_2.detach()).mean()
        loss_2 = -self.cosine_sim(p_2, z_1.detach()).mean()

        loss = 0.5 * (loss_1 + loss_2)
        return loss
        
    def get_shuffle_data(self, data):
        data_list = data.to_data_list()
        new_data_list = []
        for d in data_list:
            num_nodes = d.x.size(0)
            perm = torch.randperm(num_nodes, device=d.x.device)
            x = d.x[perm]
            idx_map = torch.full((num_nodes,), -1, dtype=torch.long, device=d.x.device)
            idx_map[perm] = torch.arange(num_nodes, device=d.x.device)
            edge_index = idx_map[d.edge_index]
            edge_attr = d.edge_attr if d.edge_attr is None else d.edge_attr.clone()
            new_data_list.append(Data(x=x, edge_index=edge_index, edge_attr=edge_attr, y=d.y if 'y' in d else None))
        return Batch.from_data_list(new_data_list)

    def get_size_graph(self, batch, num_newedge=2):
        device = batch.x.device
        edge_attr_dim = batch.edge_attr.size(1)
        new_graphs = []
        graphs = batch.to_data_list()

        for i, g in enumerate(graphs):
            if hasattr(g, "group"):
                del g.group
            if hasattr(g, "smiles"):
                del g.smiles
            if hasattr(g, "idx"):
                del g.idx
            if hasattr(g, "scaffold"):
                del g.scaffold
            if hasattr(g, "domain_id"):
                del g.domain_id
            if hasattr(g, "env_id"):
                del g.env_id
            if hasattr(g, "pyx"):
                del g.pyx
            if hasattr(g, "nodesize"):
                del g.nodesize
            if hasattr(g, "subs"):
                del g.subs
            y_i = g.y.item() if g.y.numel() == 1 else g.y
            candidates = [j for j in range(len(graphs)) if j != i and (graphs[j].y == y_i).all()]
            if not candidates:
                new_graphs.append(g)
                continue

            j = random.choice(candidates)
            g2 = graphs[j]
            n1, n2 = g.x.size(0), g2.x.size(0)
            # Compute degrees and select top nodes for cross edges
            deg1 = torch.bincount(g.edge_index.reshape(-1), minlength=n1)
            deg2 = torch.bincount(g2.edge_index.reshape(-1), minlength=n2)
            idx1 = torch.topk(deg1, k=min(num_newedge, n1)).indices.tolist()
            idx2 = torch.topk(deg2, k=min(num_newedge, n2)).indices.tolist()
            new_x = torch.cat([g.x, g2.x], dim=0)

            offset = n1
            new_ei = torch.cat([g.edge_index,
                            g2.edge_index + offset,
                            torch.tensor([idx1, [k+offset for k in idx2]],
                                         dtype=torch.long, device=device)], dim=1)

            ea1 = g.edge_attr if g.edge_attr is not None else torch.ones((g.edge_index.size(1), edge_attr_dim),     device=device)
            ea2 = g2.edge_attr if g2.edge_attr is not None else torch.ones((g2.edge_index.size(1), edge_attr_dim), device=device)
            new_cross_attr = 0.1 * torch.ones((num_newedge, edge_attr_dim), device=device)
            new_ea = torch.cat([ea1, ea2, new_cross_attr], dim=0)
            new_y = g.y

            new_graph = Data(x=new_x, edge_index=new_ei, edge_attr=new_ea, y=new_y)
            new_graphs.append(new_graph)

        return Batch.from_data_list(new_graphs)
        
    def smiles_to_pyg(self,smiles):
        if smiles is None:
            print("none here")
        dgl_g = smile2graph(smiles)
        return dgl_to_pyg(dgl_g)
        
        
    # 整个函数需要修改
    def encode_single_subgraph(self, subs_smiles):
        device = next(self.parameters()).device

        # SMILES -> PyG
        sub_graphs = [self.smiles_to_pyg(s) for s in subs_smiles]
        none_idx_list = []
        sub_graphs_filtered = []
        for idx in range(len(sub_graphs)):
            if sub_graphs[idx] is None:
                print("sub_graphs is none")
                none_idx_list.append(idx)
            else:
                sub_graphs_filtered.append(sub_graphs[idx])

        if len(sub_graphs_filtered) == 0:
            print("sub_graphs_filtered is none")
            return None, none_idx_list

        sub_batch = Batch.from_data_list(sub_graphs_filtered).to(device)

        node_h = self.gnn_encoder(sub_batch)
        row, col = sub_batch.edge_index
        edge_feat = torch.cat([node_h[row], node_h[col]], dim=-1)
        sub_feats = global_mean_pool(edge_feat, sub_batch.batch[row])

        return sub_feats, none_idx_list
      
    # 处理一张图的subs列表
    def build_subgraph_and_select(self, subs_smiles, sub_scores):
        device = next(self.parameters()).device
        sub_feats, none_idx_list = self.encode_single_subgraph(subs_smiles)


        if sub_feats is None:
            return None

        num_subs = sub_feats.size(0)
        
        if isinstance(sub_scores, list):
            scores = torch.tensor(sub_scores, dtype=torch.float32, device=device)
        else:
            scores = sub_scores.to(device, dtype=torch.float32)

        if len(none_idx_list) > 0:
            print("none_idx_list:", none_idx_list)
            mask = torch.ones(len(sub_scores),dtype=torch.bool, device=device)
            mask[none_idx_list] = False
            scores = scores[mask]
        assert scores.numel() == num_subs, "len(subs) 和 scores 长度不一致"

        src = torch.arange(num_subs, device=device).repeat_interleave(num_subs)
        dst = torch.arange(num_subs, device=device).repeat(num_subs)
        edge_weight = scores[src]

        m = edge_weight.unsqueeze(1) * sub_feats[src]
        agg = torch.zeros_like(sub_feats)
        agg = agg.index_add(0, dst, m)
        
        norm = torch.zeros(num_subs, device=device)
        norm = norm.index_add(0, src, edge_weight)
        norm = torch.clamp(norm, min=1e-6).unsqueeze(1)
        agg = agg / norm

        if self.eps ==-1:
            temp = self.sub_mp(agg)
            temp_s = temp.sigmoid()
        else:
            temp_s = self.eps
        # print(temp_s)
        # msg = self.eps* sub_feats + (1-self.eps)*agg
        msg = temp_s * sub_feats + (1-temp_s)*agg
        updated = msg

        max_idx = scores.argmax()
        selected_feat = updated[max_idx]
        return selected_feat
                
        
    def get_subs_feat_batch(self, batch, subs_info):
        device = batch.x.device
        data_list = batch.to_data_list()

        selected_feats = []
        for g in data_list:
            subs_smiles = getattr(g, "subs", [])
            sub_scores = []
            y_i = int(g.y.item()) if g.y.numel() == 1 else int(g.y)

            for smi in subs_smiles:
                info = subs_info.get(smi, None)

                if info is None:
                    label_vec = [0.0, 0.0]
                    conf = 0.0
                else:
                    label_vec, conf = info  
                label_val = label_vec[y_i]  

                score = label_val * conf
                sub_scores.append(float(score))

            feat = self.build_subgraph_and_select(subs_smiles, sub_scores)
            if feat is None:
                feat = torch.zeros(selected_feats[0].size(0), device=device)
            selected_feats.append(feat)

        sub_rep_tensor = torch.stack(selected_feats, dim=0).to(device)
        return sub_rep_tensor

    def concrete_sample(self, att_log_logit, temp):
        random_noise = torch.empty_like(att_log_logit).uniform_(1e-10, 1 - 1e-10)
        random_noise = torch.log(random_noise) - torch.log(1.0 - random_noise)
        att_bern = ((att_log_logit + random_noise) / temp).sigmoid()
        
        return att_bern
        
    # TODO: implementation of my model
    def forward(self, batch,subs_info, return_data="pred",casual_mix=False,c_pred=False,num_newedge=2,num_label = 3,adapt_select = False, alpha=0.2, shuf_after_mix=True, temp=1):

        # process subs
        subs_feat = self.get_subs_feat_batch(batch, subs_info)

        none_idx_list = []
        for idx in range(subs_feat.size(0)):
            if subs_feat[idx].all().item() == 0:
                none_idx_list.append(idx)
        mask = torch.ones(subs_feat.size(0), dtype=torch.bool, device=subs_feat.device)
        mask[none_idx_list] = False


        # size_graph
        size_graph = self.get_size_graph(batch)
#        size_pred, size_rep = self.get_pred(size_graph)
        if  self.c_in.lower()=="raw":
            size_pred, size_rep = self.classifier(size_graph, get_rep=True)
        else:
            size_pred, size_rep = self.get_eval_pred(size_graph, get_rep=True)


        batch.x=batch.x.float()
        batch.edge_attr=batch.edge_attr.float()
        

        h = self.gnn_encoder(batch)
        h = F.layer_norm(h, h.size()[1:])
        device = h.device
        row, col = batch.edge_index
        if batch.edge_attr is None:
            batch.edge_attr = torch.ones(row.size(0)).to(device)
        edge_rep = torch.cat([h[row], h[col]], dim=-1)
        pred_edge_weight = self.edge_att(edge_rep).view(-1)
        pred_edge_weight = self.concrete_sample(pred_edge_weight, temp)


        graph_rep =global_mean_pool(edge_rep*pred_edge_weight.unsqueeze(1), batch.batch[row])
        g = F.normalize(graph_rep, dim=1)
        s = F.normalize(subs_feat.detach(), dim=1)
        # s = F.normalize(subs_feat, dim=1)
        dist_loss = 1.0 - (g[mask] * s[mask]).sum(dim=1).mean()

        edge_indices, num_nodes, cum_nodes, num_edges, cum_edges = split_batch(batch)
        casual_edge_indices =defaultdict(list)
        spu_edge_indices = defaultdict(list)
        causal_edge_attr_dict = defaultdict(list)
        spu_edge_attr_dict = defaultdict(list)
        causal_weight_dict = defaultdict(list)
        spu_weight_dict = defaultdict(list)
        causal_index = torch.LongTensor([[], []]).to(device)
        causal_weight = torch.tensor([]).to(device)
        causal_edge_attr = torch.tensor([]).to(device)
        spu_index = torch.LongTensor([[], []]).to(device)
        spu_weights = torch.tensor([]).to(device)
        spu_edge_attr = torch.tensor([]).to(device)
#        edge_ratio_list = []
#        edge_weight_list = pred_edge_weight.detach().cpu().numpy()
        for edge_index, N, C,y in zip(edge_indices, num_edges, cum_edges,batch.y.detach().cpu().numpy()):
            
            # if edge_index.shape[1]==0:
            #     edge_index = troch.tensor[[0,1][1,0]].to(device)
            edge_attr = batch.edge_attr[C:C + N]
            single_mask = pred_edge_weight[C:C + N]
            if adapt_select:
                idx_reserve = torch.where(single_mask> 0.5)[0]
                idx_drop = torch.where(single_mask<= 0.5)[0]
                
                if len(idx_reserve)/N>self.ratio:
                    n_reserve = int(self.ratio * N)
                    single_mask_detach = pred_edge_weight[C:C + N].detach().cpu().numpy()
                    rank = np.argpartition(-single_mask_detach, n_reserve)
                    idx_reserve, idx_drop = rank[:n_reserve], rank[n_reserve:]
                if len(idx_reserve)/N<(1-self.ratio):
                    n_reserve = int((1-self.ratio) * N)
                    single_mask_detach = pred_edge_weight[C:C + N].detach().cpu().numpy()
                    rank = np.argpartition(-single_mask_detach, n_reserve)
                    idx_reserve, idx_drop = rank[:n_reserve], rank[n_reserve:]
                if len(idx_reserve)<num_newedge:
                    n_reserve = N
                    single_mask_detach = pred_edge_weight[C:C + N].detach().cpu().numpy()
                    idx_reserve, idx_drop = [0,1], [0,1]

                edge_ratio_list.append(len(idx_reserve)/N.detach().cpu().numpy())
            else:
                n_reserve = int(self.ratio * N)
                single_mask_detach = pred_edge_weight[C:C + N].detach().cpu().numpy()
                rank = np.argpartition(-single_mask_detach, n_reserve)
                idx_reserve, idx_drop = rank[:n_reserve], rank[n_reserve:]
            causal_edge_index =edge_index[:, idx_reserve]
            spu_edge_index = edge_index[:, idx_drop]
            casual_edge_indices[y].append(causal_edge_index)
            spu_edge_indices[y].append(spu_edge_index)

            causal_weight_dict[y].append(single_mask[idx_reserve])
            spu_weight_dict[y].append(1 - single_mask[idx_drop])
            causal_edge_attr_dict[y].append(edge_attr[idx_reserve])
            spu_edge_attr_dict[y].append(edge_attr[idx_drop])

            causal_weight = torch.cat([causal_weight, single_mask[idx_reserve]])
            causal_index = torch.cat([causal_index, edge_index[:, idx_reserve]], dim=1)
            causal_edge_attr = torch.cat([causal_edge_attr, edge_attr[idx_reserve]])


            spu_weights = torch.cat([spu_weights,  single_mask[idx_drop]])
            spu_index = torch.cat([spu_index, edge_index[:, idx_drop]], dim=1)
            spu_edge_attr = torch.cat([spu_edge_attr, edge_attr[idx_drop]])

#        batch_edge_index = torch.LongTensor([[], []]).to(device)
#        batch_edge_weight = torch.tensor([]).to(device)
#        batch_edge_attr = torch.tensor([]).to(device)
#        batch_graph_label = torch.tensor([]).to(device)
#        #num_newedge = 2
#        labels = list(casual_edge_indices.keys())
#        numlabel_batch = len(labels)
#        new_batch_label = []
#        for i in range(numlabel_batch):
#            y = labels[i]
#            for casual_part,causal_attr,casual_weight in zip(casual_edge_indices[y],causal_edge_attr_dict[y],causal_weight_dict[y]):
#
#                if numlabel_batch>1:
#                    target_label = labels[(i+1)%numlabel_batch]
#                    random_spu = random.randint(0, len(spu_edge_indices[target_label])-1)
#                    spu_part = spu_edge_indices[target_label][random_spu]
#                    spu_attr = spu_edge_attr_dict[target_label][random_spu]
#                    spu_weight = spu_weight_dict[target_label][random_spu]
#
#                else:
#                    random_spu = random.randint(0, len(spu_edge_indices[y])-1)
#                    spu_part = spu_edge_indices[y][random_spu]
#                    spu_attr = spu_edge_attr_dict[y][random_spu]
#                    spu_weight = spu_weight_dict[y][random_spu]
#
#
#
#
#                spu_part_set = torch.unique(spu_part)
#                casual_part_set = torch.unique(casual_part)
#                new_spu = random.sample(spu_part_set.detach().cpu().tolist(), num_newedge)
#                new_cau = random.sample(casual_part_set.detach().cpu().tolist(), num_newedge)
#                new_edges = torch.tensor([new_cau, new_spu]).to(device)
#                # new_attr = batch_edge_attr[:num_newedge].to(device)
#                new_attr = 0.1 * torch.ones((num_newedge, causal_attr.size(1)), device=device)
#                new_weight = 0.1 * torch.ones(num_newedge).reshape(-1).to(device)
#                label = torch.tensor(y).reshape(-1).to(device)
#                new_graph = torch.cat([new_edges,spu_part,casual_part],dim=1)
#                new_graph_weight = torch.cat([new_weight,casual_weight,spu_weight])
#                new_edge_attr = torch.cat([new_attr,causal_attr,spu_attr],dim=0)
#                batch_edge_index = torch.cat([batch_edge_index, new_graph], dim=1)
#                batch_edge_weight = torch.cat([batch_edge_weight,new_graph_weight])
#                batch_edge_attr = torch.cat([batch_edge_attr, new_edge_attr])
#                batch_graph_label = torch.cat([batch_graph_label,label])

        if self.c_in.lower() == "raw":
            causal_x, causal_index, causal_batch, _ = relabel(batch.x, causal_index, batch.batch)
            spu_x, spu_index, spu_batch, _ = relabel(batch.x, spu_index, batch.batch)
#            new_x, new_edge_index, new_batch, _ = relabel(batch.x, batch_edge_index, batch.batch)
        else:
            causal_x, causal_index, causal_batch, _ = relabel(h, causal_index, batch.batch)
#            new_x, new_edge_index, new_batch, _ = relabel(h, batch_edge_index, batch.batch)
            spu_x, spu_index, spu_batch, _ = relabel(h, spu_index, batch.batch)
            batch.x = h
#            batch = DataBatch.Batch(batch=batch.batch,
#                                edge_index=batch.edge_index,
#                                x=h,
#                                edge_attr=batch.edge_attr,
#                                y=batch.y
#                                )
#        if shuf_after_mix:
#            new_x, new_edge_index, batch_edge_attr, new_batch = self.shuffle_per_g(new_x, new_edge_index, batch_edge_attr, new_batch)
#        mix_batch = DataBatch.Batch(batch=new_batch,
#                            edge_index=new_edge_index,
#                            x=new_x,
#                            edge_attr=batch_edge_attr,
#                            y=batch_graph_label
#                            )
        
        batch_pred, batch_rep = self.classifier(batch, get_rep=True)
#        mix_pred, mix_rep = self.classifier(mix_batch, get_rep=True)

        
        causal_graph = DataBatch.Batch(batch=causal_batch,
                                   edge_index=causal_index,
                                   x=causal_x,
                                   edge_attr=causal_edge_attr,
                                   y  = batch.y)
        spu_graph = DataBatch.Batch(batch=spu_batch,
                                   edge_index=spu_index,
                                   x=spu_x,
                                   edge_attr=spu_edge_attr,
                                   y  = batch.y)
                                   
        _, cau_feat = self.classifier(causal_graph, get_rep=True)
        _, spu_feat = self.classifier(spu_graph, get_rep=True)
        
        
#
#        my_set_masks(causal_weight, self.classifier)
#        c_batch_pred = self.classifier(causal_graph)
#        my_clear_masks(self.classifier)
#
#
#        c_graph_pred = self.classifier(causal_graph)

    
#
#        shuf_graph = self.get_shuffle_data(batch)
#        shuf_pred, shuf_rep = self.get_pred(shuf_graph)
        
        
        num_graphs = batch.y.size(0)
        perm = torch.randperm(num_graphs, device=batch.y.device)
        shuf_causal_batch = torch.zeros_like(causal_batch)
        for new_idx, old_idx in enumerate(perm):
            shuf_causal_batch[causal_batch == old_idx] = new_idx
        shuf_y = batch.y[perm]
        
        lam = np.random.beta(alpha, alpha)
        lam = max(lam, (1-lam))
        cau_mix_x_list, cau_mix_edge_index_list, cau_mix_edge_attr_list = [], [], []
        cau_mix_batch_list, cau_mix_weight_list, cau_mix_y_list = [], [], []
        for n in range(num_graphs):
            node_mask1 = (causal_batch == n)
            edge_mask1 = (causal_batch[causal_index[0]] == n)
            x1  = causal_x[node_mask1]
            ei1 = causal_index[:, edge_mask1]
            ea1 = causal_edge_attr[edge_mask1]
            w1  = causal_weight[edge_mask1]
            y1  = batch.y[n]

            node_mask2 = (shuf_causal_batch == n)
            edge_mask2 = (shuf_causal_batch[causal_index[0]] == n)
            x2  = causal_x[node_mask2]
            ei2 = causal_index[:, edge_mask2]
            ea2 = causal_edge_attr[edge_mask2]
            w2  = causal_weight[edge_mask2]
            y2  = shuf_y[n]

            offset = x1.size(0)
            ei2 = ei2 + offset

            new_x  = torch.cat([x1, x2], dim=0)
            new_ei = torch.cat([ei1, ei2], dim=1)
            new_ea = torch.cat([ea1, ea2], dim=0)

            idx1 = random.sample(range(x1.size(0)), num_newedge)
            idx2 = random.sample(range(x2.size(0)), num_newedge)
            new_cross_edges = torch.tensor([idx1, [i + offset for i in idx2]], device=new_x.device, dtype=torch.long)
            new_cross_attr = 0.1 * torch.ones((num_newedge, ea1.size(1)), device=new_x.device)
            new_cross_weight = 0.1 * torch.ones(num_newedge, device=new_x.device)

            new_ei = torch.cat([new_ei, new_cross_edges], dim=1)
            new_ea = torch.cat([new_ea, new_cross_attr], dim=0)
            new_w = torch.cat([lam * w1, (1.0 - lam) * w2, new_cross_weight], dim=0)
            onehot_y1 = F.one_hot(y1.long(), num_classes=num_label).to(device)
            onehot_y2 = F.one_hot(y2.long(), num_classes=num_label).to(device)
            new_y = lam * onehot_y1 + (1.0 - lam) * onehot_y2
            new_batch = torch.full((new_x.size(0),), n, device=new_x.device, dtype=torch.long)
            cau_mix_x_list.append(new_x)
            cau_mix_edge_index_list.append(new_ei)
            cau_mix_edge_attr_list.append(new_ea)
            cau_mix_weight_list.append(new_w)
            cau_mix_y_list.append(new_y)
            cau_mix_batch_list.append(new_batch)
            
        cau_mix_x = torch.cat(cau_mix_x_list, dim=0)
        cau_mix_edge_index = torch.cat(cau_mix_edge_index_list, dim=1)
        cau_mix_edge_attr = torch.cat(cau_mix_edge_attr_list, dim=0)
        cau_mix_weight = torch.cat(cau_mix_weight_list, dim=0)
        cau_mix_batch = torch.cat(cau_mix_batch_list, dim=0)
        cau_mix_y = torch.stack(cau_mix_y_list, dim=0)
        if shuf_after_mix:
            cau_mix_x, cau_mix_edge_index, cau_mix_edge_attr, cau_mix_batch = self.shuffle_per_g(cau_mix_x, cau_mix_edge_index, cau_mix_edge_attr, cau_mix_batch)
        cau_mix_graph = DataBatch.Batch(
                        batch=cau_mix_batch,
                        edge_index=cau_mix_edge_index,
                        x=cau_mix_x,
                        edge_attr=cau_mix_edge_attr,
                        y=cau_mix_y )
                        
        my_set_masks(cau_mix_weight, self.classifier)
        cau_mix_pred, cau_mix_rep = self.classifier(cau_mix_graph, get_rep=True)
        my_clear_masks(self.classifier)
        
        simsiam_loss = self.get_simsiam_loss(cau_mix_rep, size_rep)
        
        # if casual_mix:
        if True:
            
            my_set_masks(causal_weight, self.classifier)
            mixup_x, mixup_y = self.classifier(causal_graph, if_mix=True,num_classes=num_label,alpha = alpha)
            my_clear_masks(self.classifier)
            
            return mixup_x,mixup_y,batch_pred, cau_mix_pred, cau_mix_y, size_pred, simsiam_loss, size_rep, batch_rep, dist_loss
        
   
    
    def get_eval_pred(self, batch, get_rep=False):
    #    device = batch.y.device
       node_feat = self.gnn_encoder(batch)
       batch.x = node_feat
       pred, rep = self.classifier(batch, get_rep=True)
       if get_rep:
        return pred, rep
        
       return pred

        
#    def get_pred(self, batch):
#        device = batch.y.device
#        node_feat = self.gnn_encoder(batch)
#        row, col = batch.edge_index
#        if batch.edge_attr is None:
#            batch.edge_attr = torch.ones(row.size(0)).to(device)
#        edge_feat = torch.cat([node_feat[row], node_feat[col]], dim=-1)
#        score_on_edge = self.edge_att(edge_feat).view(-1)
#        score_on_edge = self.concrete_sample(score_on_edge, 1)
#        my_set_masks(score_on_edge, self.classifier)
#        pred, rep = self.classifier(batch, get_rep =True)
#        my_clear_masks(self.classifier)
#
#        return pred, rep

        
        
