import json
import torch

def export_smiles_y_to_json(data, dataset_name="GOOD-HIV"):
    smiles_list = data.smiles
    y_list = data.y

    if isinstance(smiles_list, torch.Tensor):
        smiles_list = smiles_list.cpu().tolist()
    if isinstance(y_list, torch.Tensor):
        y_list = y_list.cpu().tolist()

    y_list = [int(y[0]) if isinstance(y, (list, tuple)) else int(y) for y in y_list]

    json_data = {
        "dataset": dataset_name,
        "train": []
    }

    for smi, y in zip(smiles_list, y_list):
        json_data["train"].append({
            "smiles": smi,
            "y": y
        })
    return json_data

import os

dataset_path = "data/GOODHIV/size/processed/covariate_train.pt"
out_path = "preprocess/GOODHIV/size/covariate"
out_file = os.path.join(out_path, "smiles.json")
data_tuple = torch.load(dataset_path)

data, meta_info = data_tuple  
json_data = export_smiles_y_to_json(data, dataset_path)
if not os.path.exists(out_path):
    os.makedirs(out_path)
with open(out_file, "w", encoding="utf-8") as f:
    json.dump(json_data, f, indent=2, ensure_ascii=False)

print(f"export:{out_file}")
