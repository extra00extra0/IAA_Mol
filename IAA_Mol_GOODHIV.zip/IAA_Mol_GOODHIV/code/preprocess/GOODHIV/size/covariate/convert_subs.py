#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
import sys
import ast
from collections import OrderedDict
from typing import Any, Union

def list_string_to_brace_string(s: str) -> Union[str, None]:
    """
    "['a','b']" -> "{'a', 'b'}"
    """
    try:
        parsed = ast.literal_eval(s)
    except Exception:
        return None

    if isinstance(parsed, (list, tuple)):
        # 去重但保序
        seen = set()
        ordered = []
        for x in parsed:
            if not isinstance(x, str):
                return None
            if x not in seen:
                seen.add(x)
                ordered.append(x)
        inner = ", ".join(f"'{item}'" for item in ordered)
        return "{" + inner + "}"
    return None

def list_value_to_brace_string(v: Any) -> Union[str, None]:
    """
    把真实的 list/tuple -> 字符串形式的花括号 "{'..', '..'}"
    若不是纯字符串列表则返回 None
    """
    if isinstance(v, (list, tuple)):
        for x in v:
            if not isinstance(x, str):
                return None
        # 去重保序
        seen = set()
        ordered = []
        for x in v:
            if x not in seen:
                seen.add(x)
                ordered.append(x)
        inner = ", ".join(f"'{item}'" for item in ordered)
        return "{" + inner + "}"
    return None

def transform(obj: Any) -> Any:
    if isinstance(obj, list):
        return [transform(x) for x in obj]

    if isinstance(obj, dict):
        # 若需要保序，可用 OrderedDict（写回时 json 会保持插入顺序）
        new_d = OrderedDict()
        for k, v in obj.items():
            if k == "subs":
                # 先递归处理其值（如果里面还有结构）
                v_transformed = transform(v)

                # 1) 如果是字符串样式的列表
                if isinstance(v_transformed, str):
                    converted = list_string_to_brace_string(v_transformed)
                    if converted is not None:
                        new_d["substructure"] = converted
                        continue  # 已完成重命名与转换

                # 2) 如果是实际的 list/tuple
                converted2 = list_value_to_brace_string(v_transformed)
                if converted2 is not None:
                    new_d["substructure"] = converted2
                    continue

                # 3) 其它情况：仅重命名键
                new_d["substructure"] = v_transformed
            else:
                new_d[k] = transform(v)
        return new_d

    return obj

def main():
    if len(sys.argv) < 2:
        print("用法：python convert_subs.py input.json [output.json]")
        sys.exit(1)

    in_path = sys.argv[1]
    out_path = sys.argv[2] if len(sys.argv) >= 3 else in_path

    with open(in_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    data_out = transform(data)

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data_out, f, ensure_ascii=False, indent=2)

    print(f"已写出：{out_path}")

if __name__ == "__main__":
    main()