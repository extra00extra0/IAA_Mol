import os
import json
from tqdm import tqdm


def process(bmethod):
    result = {}
    print(f'[INFO] Loading substructures from {bmethod}')
    prefix = 'substructure' if bmethod == 'brics' else 'substructure_recap'
    for file in os.listdir(prefix):
        if not file.endswith(('.json', '.txt')):
            continue
        if file.endswith('.json'):
            print("[INFO] loading file:", os.path.join(prefix, file))
            with open(os.path.join(prefix, file)) as Fin:
                INFO = json.load(Fin)
            for k, v in tqdm(INFO.items()):
                assert type(eval(v)) == set, f'Invalid value1 {v}'
                result[k] = v

        else:
            # print("[INFO] loading file:", os.path.join(prefix, file))
            with open(os.path.join(prefix, file)) as Fin:
                for lin in tqdm(Fin):
                    lin = lin.strip()
                    if not lin:
                        continue

                    try:
                        obj = json.loads(lin)
                    except json.JSONDecodeError as e:
                        print(f"[WARN] Invalid JSON line: {lin[:100]} ... ({e})")
                        continue

                    smiles = obj.get("smiles")
                    subs   = obj.get("substructure")

                    assert smiles is not None, f"Missing smiles in line: {lin}"
                    assert isinstance(subs, list), f"substructure must be list, got {type(subs)}"

                    result[smiles] = subs

        # else:
        #     with open(os.path.join(prefix, file)) as Fin:
        #         for lin in tqdm(Fin):
        #             if len(lin) <= 1:
        #                 continue
        #             lin = lin.strip().split('\t')
        #             assert len(lin) == 2, f'Invalid Line {lin}'
        #             assert type(eval(lin[1])) == set, \
        #                 'Invalid value1 {}'.format(lin[1])
        #             result[lin[0]] = lin[1]

    # with open('all_smiles.json') as Fin:
    #     all_smiles = json.load(Fin)

    new_result, empty_num = {}, 0
    for k, v in result.items():
        # v = eval(v)
        if len(v) == 0:
            print(f'[INFO] {k} have no substruct, use it self as substruct')
            new_result[k], empty_num = set([k]), empty_num + 1
        else:
            new_result[k] = v

    print(f'[INFO] there are {empty_num} mols have no substruct')

    result = {k: str(v) for k, v in new_result.items()}


    with open('smiles.json') as Fin:
        INFO = json.load(Fin)
    new_mol_list = []
    for lin in INFO['train']:
        try:
            lin['subs'] = result[lin['smiles']]
        except KeyError:
            print(f"[WARN] SMILES not found: {lin['smiles']}")
            lin['subs'] = [lin['smiles']]
            continue  # 跳过该分子，不中断整个程序

        new_mol_list.append(lin)
    INFO['train']= new_mol_list
    with open('data_processed.json', 'w') as Fout:
        json.dump(INFO, Fout, indent=4)


    


if __name__ == '__main__':
    if os.path.exists('substructure'):
        process('brics')
    # if os.path.exists('substructure_recap'):
    #     process('recap')
