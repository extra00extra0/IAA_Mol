# !/bin/bash


# python main.py --exp_id only_dist_02 --size_pred_w 0 --cau_mix_w 0 --simsiam_w 0 --vrex_w 0 --epoch 10 --lr 0.2 --seed [0,1,2]
# python main.py --cau_mix_w 0 --simsiam_w 0 --vrex_w 0 --dist_w 0 --epoch 10 --caus 0 --lr 1e-2 --exp_id only_caus_lr02 --seed [0,1,2]

# python main.py --size_pred_w 0 --cau_mix_w 0 --simsiam_w 0 --vrex_w 0 --dist_w 0 --epoch 10 --exp_id no_every --seed [0,1,2]

# python main.py --size_pred_w 0 --cau_mix_w 0 --simsiam_w 0 --vrex_w 0 --dist_w 0 --epoch 10 --lr 1e-2 --exp_id no_every_lr02_2 --seed [0,1,4]
# python main.py --size_pred_w 0 --cau_mix_w 0 --simsiam_w 0 --vrex_w 0 --dist_w 0 --epoch 10 --lr 1e-5 --exp_id no_every_lr05 --seed [3,4]
# python main.py --dropout 0.5 --exp_id dp0.5 --seed [0,1,2]

# python main.py --dataset drugood_lbap_core_ec50_assay --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_assay_brics_substructures.json --exp_id ec_assay_1 --seed [0,1,2,3,4]
# python main.py --dataset drugood_lbap_core_ec50_scaffold --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_scaffold_brics_substructures.json --exp_id ec_scaffold_1 --seed [3,4]
# python main.py --dataset drugood_lbap_core_ec50_size --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_size_brics_substructures.json --exp_id ec_size_1 --seed [2,3,4]
# python main.py --dataset drugood_lbap_core_ic50_assay --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_assay_brics_substructures.json --exp_id ic_assay_1 --seed [0,1]
# python main.py --dataset drugood_lbap_core_ic50_scaffold --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_scaffold_brics_substructures.json --exp_id ic_scaffold_1 --seed [1,1]
# python main.py --dataset drugood_lbap_core_ic50_size --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_size_brics_substructures.json --exp_id ic_size_1 --seed [3,4]





# python main.py --dataset drugood_lbap_core_ec50_assay --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_assay_brics_substructures.json --exp_id ec_assay_2 --seed [0,1,2,3,4]
# python main.py --dataset drugood_lbap_core_ec50_assay --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_assay_brics_substructures.json --exp_id ec_assay_3 --seed [0,1,2,3,4]
# python main.py --dataset drugood_lbap_core_ec50_size --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_size_brics_substructures.json --exp_id ec_size_2 --seed [0,1,2,3,4]
# python main.py --dataset drugood_lbap_core_ec50_scaffold --subs_path ./data/DrugOOD/ec50/lbap_core_ec50_scaffold_brics_substructures.json --exp_id ec_scaffold_2 --seed [0,1,2,3,4]
# python main.py --dataset drugood_lbap_core_ic50_assay --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_assay_brics_substructures.json --exp_id ic_assay_2 --seed [0,1,2,3,4]
# python main.py --dataset drugood_lbap_core_ic50_size --subs_path ./data/DrugOOD/ic50/lbap_core_ic50_size_brics_substructures.json --exp_id ic_size_2 --seed [0,1,2,3,4]



# python main.py --dataset drugood_lbap_general_ec50_assay --emb_dim 64 --exp_id general_1 --seed [0]
# python main.py --dataset drugood_lbap_general_ec50_assay --emb_dim 128 --exp_id general_2 --seed [0]
# python main.py --dataset drugood_lbap_general_ec50_assay --emb_dim 64 -c_in feat --exp_id general_3 --seed [0]
# python main.py --dataset drugood_lbap_general_ec50_assay --emb_dim 128 -c_in feat --exp_id general_4 --seed [0]
# python main.py --dataset drugood_lbap_general_ec50_assay --proto_w 0 --cau_mix_w 0 --size_pred_w 0 --simsiam_w 0 --vrex_w 0 --exp_id general_5 --seed [0,1,2,3,4]
# python main.py --dataset drugood_lbap_general_ec50_assay --shuf_after_mix 1 --exp_id general_6 --seed [0]
# python main.py --dataset drugood_lbap_general_ec50_assay --vrex_w 0 --exp_id general_7 --seed [0]
# python main.py --dataset drugood_lbap_general_ec50_assay --simsiam_w 0 --exp_id general_8 --seed [0]
# python main.py --dataset drugood_lbap_general_ec50_assay --proto_w 0 --exp_id general_9 --seed [0]
# python main.py --dataset drugood_lbap_general_ec50_assay --num_layers 3 --exp_id general_10 --seed [0]
# python main.py --dataset drugood_lbap_general_ec50_assay --dropout 0.5 --exp_id general_11 --seed [0]
# python main.py --dataset drugood_lbap_general_ec50_assay --cau_mix_w 0 --exp_id general_12 --seed [0]
# python main.py --dataset drugood_lbap_general_ec50_assay --lr 1e-2 --exp_id general_13 --seed [0]
# python main.py --dataset drugood_lbap_general_ec50_assay --lr 1e-4 --exp_id general_14 --seed [0]

# python main.py --dataset drugood_lbap_refined_ec50_assay --emb_dim 64 --exp_id refined_1 --seed [0]
# python main.py --dataset drugood_lbap_refined_ec50_assay --emb_dim 128 --exp_id refined_2 --seed [0]
# python main.py --dataset drugood_lbap_refined_ec50_assay --emb_dim 64 -c_in feat --exp_id refined_3 --seed [0]
# python main.py --dataset drugood_lbap_refined_ec50_assay --emb_dim 128 -c_in feat --exp_id refined_4 --seed [0]
# python main.py --dataset drugood_lbap_refined_ec50_assay --proto_w 0 --cau_mix_w 0 --size_pred_w 0 --simsiam_w 0 --vrex_w 0 --exp_id refined_5 --seed [0]
# python main.py --dataset drugood_lbap_refined_ec50_assay --shuf_after_mix 1 --exp_id refined_6 --seed [0]
# python main.py --dataset drugood_lbap_refined_ec50_assay --vrex_w 0 --exp_id refined_7 --seed [0]
# python main.py --dataset drugood_lbap_refined_ec50_assay --simsiam_w 0 --exp_id refined_8 --seed [0]
# python main.py --dataset drugood_lbap_refined_ec50_assay --proto_w 0 --exp_id refined_9 --seed [0]
# python main.py --dataset drugood_lbap_refined_ec50_assay --num_layers 3 --exp_id refined_10 --seed [0]
# python main.py --dataset drugood_lbap_refined_ec50_assay --dropout 0.5 --exp_id refined_11 --seed [0]
# python main.py --dataset drugood_lbap_refined_ec50_assay --cau_mix_w 0 --exp_id refined_best --seed [0,1,2,3,4]
# python main.py --dataset drugood_lbap_refined_ec50_assay --lr 1e-2 --exp_id refined_13 --seed [0]
# python main.py --dataset drugood_lbap_refined_ec50_assay --lr 1e-4 --exp_id refined_14 --seed [0]
# python main.py --dataset drugood_lbap_refined_ec50_assay --cau_mix_w 0 --simsiam_w 0 --exp_id refined_15 --seed [0]
# python main.py --dataset drugood_lbap_core_ec50_size -c_in feat --emb_dim 64 --shuf_after_mix 1 --num_layers 3 --dropout 0.5 --exp_id dru_ec_size_2 --seed [0]
# python main.py --dataset drugood_lbap_core_ec50_size -c_in feat --emb_dim 64 --shuf_after_mix 1 --num_layers 3 --dropout 0.5 --exp_id dru_ec_size_3 --seed [0]

# python main.py --dataset drugood_lbap_core_ec50_scaffold -c_in feat --vrex_w 0 --simsiam_w 0 --cau_mix_w 0 --batch_size 16 --exp_id dru_ec_scaf_1 --seed [0]
# python main.py --dataset drugood_lbap_core_ec50_scaffold -c_in feat --vrex_w 0 --simsiam_w 0 --cau_mix_w 0 --batch_size 16 --exp_id dru_ec_scaf_2 --seed [0]
# python main.py --dataset drugood_lbap_core_ec50_scaffold -c_in feat --vrex_w 0 --simsiam_w 0 --cau_mix_w 0 --batch_size 16 --exp_id dru_ec_scaf_3 --seed [0]

# python main.py --dataset BBBP --lr 1e-4 --exp_id BBBP_1 --seed [0]
# python main.py --dataset BBBP --lr 1e-4 --exp_id BBBP_2 --seed [0]
# python main.py --dataset BBBP --lr 1e-4 --exp_id BBBP_3 --seed [0]

# python main.py --dataset drugood_lbap_core_ec50_assay --exp_id dru_ec_assay_1 --seed [0]
# python main.py --dataset drugood_lbap_core_ec50_assay --exp_id dru_ec_assay_2 --seed [0]
# python main.py --dataset drugood_lbap_core_ec50_assay --exp_id dru_ec_assay_3 --seed [0]

# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --simsiam_w 0 --size_pred_w 1 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --epoch 8 --caus 1 --exp_id GH_size_concept_size_ep8_1 --seed [1]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --simsiam_w 0 --size_pred_w 1 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --epoch 8 --caus 1 --exp_id GH_size_concept_size_ep8_3 --seed [3]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --simsiam_w 0 --size_pred_w 1 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --epoch 15 --caus 1 --exp_id GH_size_concept_size_ep15_1 --seed [1]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --simsiam_w 0 --size_pred_w 1 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --epoch 15 --caus 1 --exp_id GH_size_concept_size_ep15_3 --seed [3]


# ***********************************8********************************************&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --dropout 0.5 --dist 0 --epoch 10 --exp_id GH_size_concept_size_dp05_3 --seed [3]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --dropout 0.5 --dist 0 --epoch 10 --exp_id GH_size_concept_size_dp05_4 --seed [4]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --dropout 0.5 --dist 0 --epoch 10 --exp_id GH_size_concept_size_dp05_2 --seed [2]

# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --num_layers 3 --dist 0 --epoch 10 --exp_id GH_size_concept_size_layer3_dist0_0 --seed [0]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --num_layers 3 --dist 0 --epoch 10 --exp_id GH_size_concept_size_layer3_dist0_1 --seed [1]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --num_layers 3 --dist 0 --epoch 10 --exp_id GH_size_concept_size_layer3_dist0_2 --seed [2]

# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --num_layers 3 --epoch 10 --exp_id GH_size_concept_size_layer3_0 --seed [0]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --num_layers 3 --epoch 10 --exp_id GH_size_concept_size_layer3_1 --seed [1]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --num_layers 3 --epoch 10 --exp_id GH_size_concept_size_layer3_2 --seed [2]


# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 0 --epoch 10 --exp_id GH_scaf_dist_1_cova_00 --seed [0]
# # python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 0 --epoch 10 --exp_id GH_scaf_dist_1_cova_1 --seed [1]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 0 --epoch 10 --exp_id GH_scaf_dist_1_cova_02 --seed [2]
# # python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 0 --epoch 10 --exp_id GH_scaf_dist_1_cova_3 --seed [3]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 0 --epoch 10 --exp_id GH_scaf_dist_1_cova_04 --seed [4]


#****************************************************************************************************************************************************
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --simsiam_w 0 --size_pred_w 1 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --epoch 10 --caus 0 --exp_id GH_size_concept_size_caus0_ep10_0 --seed [0]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --simsiam_w 0 --size_pred_w 1 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --epoch 10 --caus 0 --exp_id GH_size_concept_size_caus0_ep10_1 --seed [1]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --simsiam_w 0 --size_pred_w 1 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --epoch 10 --caus 0 --exp_id GH_size_concept_size_caus0_ep10_2 --seed [2]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --simsiam_w 0 --size_pred_w 1 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --epoch 10 --caus 0 --exp_id GH_size_concept_size_caus0_ep10_3 --seed [3]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/concept --domain size --shift concept -c_in feat --emb_dim 64 --simsiam_w 0 --size_pred_w 1 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --epoch 10 --caus 0 --exp_id GH_size_concept_size_caus0_ep10_4 --seed [4]


# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 1 --epoch 10 --exp_id GH_scaf_dist_1_cova_0 --seed [0]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 1 --epoch 10 --exp_id GH_scaf_dist_1_cova_2 --seed [2]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 1 --epoch 10 --exp_id GH_scaf_dist_1_cova_4 --seed [4]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 1 --epoch 10 --exp_id GH_scaf_dist_1_cova_0 --seed [0]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 1 --epoch 10 --exp_id GH_scaf_dist_1_cova_2 --seed [2]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 1 --epoch 10 --exp_id GH_scaf_dist_1_cova_4 --seed [4]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 1 --epoch 10 --exp_id GH_scaf_dist_1_cova_0 --seed [0]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 1 --epoch 10 --exp_id GH_scaf_dist_1_cova_2 --seed [2]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 1 --epoch 10 --exp_id GH_scaf_dist_1_cova_4 --seed [4]


# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_0 --seed [0]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_1 --seed [1]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_2 --seed [2]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_3 --seed [3]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_4 --seed [4]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_0 --seed [0]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_1 --seed [1]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_2 --seed [2]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_3 --seed [3]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_4 --seed [4]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_0 --seed [0]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_1 --seed [1]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_2 --seed [2]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_3 --seed [33
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_4 --seed [4]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_0 --seed [0]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_1 --seed [1]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_2 --seed [2]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_3 --seed [3]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_4 --seed [4]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_0 --seed [0]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_1 --seed [1]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_2 --seed [2]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_3 --seed [3]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/concept --domain scaffold --shift concept --simsiam_w 0 --cau_mix_w 0 --size_pred_w 0 --vrex_w 0 --dist_w 0 --caus 0  --exp_id GH_scaf_concept_caus0_4 --seed [4]


python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/covariate --domain size --shift covariate --simsiam_w 0 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --size_pred_w 1 --num_prototype 10 --epoch 10 --exp_id GH_size_cova_only_size_0 --seed [0]
python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/covariate --domain size --shift covariate --simsiam_w 0 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --size_pred_w 1 --num_prototype 10 --epoch 10 --exp_id GH_size_cova_only_size_1 --seed [1]
python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/covariate --domain size --shift covariate --simsiam_w 0 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --size_pred_w 1 --num_prototype 10 --epoch 10 --exp_id GH_size_cova_only_size_2 --seed [2]
python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/covariate --domain size --shift covariate --simsiam_w 0 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --size_pred_w 1 --num_prototype 10 --epoch 10 --exp_id GH_size_cova_only_size_3 --seed [3]
python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/covariate --domain size --shift covariate --simsiam_w 0 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --size_pred_w 1 --num_prototype 10 --epoch 10 --exp_id GH_size_cova_only_size_4 --seed [4]


# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 1 --epoch 10 --exp_id GH_scaf_dist_1_cova_1 --seed [1]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 1 --epoch 10 --exp_id GH_scaf_dist_1_cova_3 --seed [3]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 1 --epoch 10 --exp_id GH_scaf_dist_1_cova_1 --seed [1]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/scaffold/covariate --domain scaffold --shift covariate --batch_size 64 --dist_w 1 --epoch 10 --exp_id GH_scaf_dist_1_cova_3 --seed [3]


# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/covariate --domain size --shift covariate --simsiam_w 0 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --size_pred_w 1 --num_prototype 10 --epoch 10 --exp_id GH_size_cova_only_size_2 --seed [2]
# python main.py --dataset GOODHIV --subs_path ./preprocess/GOODHIV/size/covariate --domain size --shift covariate --simsiam_w 0 --cau_mix_w 0 --vrex_w 0 --dist_w 0 --size_pred_w 1 --num_prototype 10 --epoch 10 --exp_id GH_size_cova_only_size_2 --seed [2]

#****************************************************************************************************************************************************

# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --exp_id GH_scaf_cova_1 --seed [0]
# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --exp_id GH_scaf_cova_2 --seed [0]
# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --exp_id GH_scaf_cova_3 --seed [0]

# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --cau_mix_w 0.1 --exp_id cau_mix_w_0.1 --seed [0,1,2,3,4]
# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --cau_mix_w 0.5 --exp_id cau_mix_w_0.5 --seed [0,1,2,3,4]
# # python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --cau_mix_w 1 --exp_id cau_mix_w_1 --seed [0,1,2,3,4]
# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --cau_mix_w 2 --exp_id cau_mix_w_2 --seed [0,1,2,3,4]
# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --cau_mix_w 4 --exp_id cau_mix_w_4 --seed [0,1,2,3,4]

# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --simsiam_w 0.1 --exp_id simsiam_w_0.1 --seed [0,1,2,3,4]
# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --simsiam_w 0.5 --exp_id simsiam_w_0.5 --seed [2,3,4]
# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --simsiam_w 2 --exp_id simsiam_w_2 --seed [0,1,2,3,4]
# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --simsiam_w 4 --exp_id simsiam_w_4 --seed [0,1,2,3,4]

# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --vrex_w 0.1 --exp_id vrex_w_0.1 --seed [0,1,2,3,4]
# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --vrex_w 0.5 --exp_id vrex_w_0.5 --seed [0,1,2,3,4]
# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --vrex_w 2 --exp_id vrex_w_2 --seed [0,1,2,3,4]
# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --proto_w 0.2 --exp_id proto_w_0.2 --seed [0,1,2,3,4]
# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --proto_w 0.3 --exp_id proto_w_0.3 --seed [0,1,2,3,4]

# python main.py --dataset drugood_lbap_core_ec50_assay --proto_w 0 --epoch 1 --pretrain 1 --exp_id try_tsne --seed [0]
# python main.py --dataset BACE --cau_mix_w 0 --exp_id ace-best-3 --seed [0,1,2,3,4]
# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --exp_id scaf-cov-try --seed [2,4]

# python main.py --dataset drugood_lbap_core_ic50_assay -c_in feat --emb_dim 128 --seed [0,1,2,3,4]
# python main.py --dataset GOODHIV --domain size --shift concept --proto_w 0 -c_in feat --emb_dim 64 --exp_id size-conc --seed [2,4]

# python main.py --lr 1e-5 --dataset BACE
# python main.py --lr 1e-4 --dataset BACE
# python main.py --lr 1e-2 --dataset BACE
# python main.py --shuf_after_mix 1 --dataset BACE
# python main.py --vrex_w 0 --dataset BACE
# python main.py --simsiam_w 0 --dataset BACE
# python main.py --proto_w 0 --dataset BACE
# python main.py --dropout 0.5 --dataset BACE
# python main.py --cau_mix_w 0 --dataset BACE
# python main.py --size_pred_w 0 --dataset BACE
# python main.py --batch_size 64 --dataset BACE
# python main.py --caus 0 --dataset BACE

# python main.py --lr 1e-5 --dataset BBBP
# python main.py --lr 1e-4 --dataset BBBP --exp_id bbbp-best --seed [0,1,2,3,4]
# python main.py --dataset BACE --proto_w 0 --exp_id best-2 --seed [0,1,2,3,4]
# python main.py --lr 1e-2 --dataset BBBP
# python main.py --shuf_after_mix 1 --dataset BBBP
# python main.py --vrex_w 0 --dataset BBBP
# python main.py --simsiam_w 0 --dataset BBBP
# python main.py --proto_w 0 --dataset BBBP
# python main.py --dropout 0.5 --dataset BBBP
# python main.py --cau_mix_w 0 --dataset BBBP
# python main.py --size_pred_w 0 --dataset BBBP
# python main.py --batch_size 64 --dataset BBBP
# python main.py --caus 0 --dataset BBBP



# python main.py --dataset drugood_lbap_core_ec50_assay 
# python main.py --dataset drugood_lbap_core_ec50_scaffold
# python main.py --dataset drugood_lbap_core_ec50_size 
# python main.py --dataset drugood_lbap_core_ic50_assay 
# python main.py --dataset drugood_lbap_core_ic50_scaffold 
# python main.py --dataset drugood_lbap_core_ic50_size 


# python main.py --dataset drugood_lbap_core_ic50_assay -c_in feat --emb_dim 123 --num_layers 3 --dropout 0.5 --simsiam_w 0 --exp_id i_as_another_best --seed [0,1,2,3,4]

# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --exp_id scaf-cov-try --seed [0]
# python main.py --dataset GOODHIV --domain scaffold --shift covariate --dropout 0.5 --batch_size 64 --num_prototype 10 --exp_id scaf-cov-best-4 --seed [4]
# python main.py --dataset GOODHIV --domain size --shift concept --proto_w 0 -c_in feat --emb_dim 64 --temp 0.3 --exp_id siz-con-tmp03 --seed [0]
# python main.py --dataset GOODHIV --domain size --shift covariate --size_pred_w 0 --num_prototype 5 --exp_id siz_con-pro-5 --seed [0]
# python main.py --dataset GOODHIV --domain size --shift covariate --size_pred_w 0 --num_prototype 10 --exp_id siz_con-pro-10 --seed [0]
# python main.py --dataset GOODHIV --domain size --shift covariate --size_pred_w 0 --num_prototype 13 --exp_id siz_con-pro-13 --seed [0]

# python main.py --dataset drugood_lbap_core_ic50_assay -c_in feat --emb_dim 128 --num_prototype 5 --exp_id i-as-best-pro-5 --seed [0]
# python main.py --dataset drugood_lbap_core_ic50_assay -c_in feat --emb_dim 128 --num_prototype 10 --exp_id i-as-best-pro-10 --seed [0]
# python main.py --dataset drugood_lbap_core_ic50_assay -c_in feat --emb_dim 128 --num_prototype 13 --exp_id i-as-best-pro-13 --seed [0]
# python main.py --dataset GOODHIV --domain size --shift covariate --size_pred_w 0 --num_prototype 10 --exp_id siz_cova-no-siz-10 --seed [0,1] 
# python main.py --dataset GOODHIV --domain size --shift covariate --pretrain_epoch 10 --seed [0]
# python main.py --dataset GOODHIV --domain size --shift concept --proto_w 0 -c_in feat  --exp_id siz_conc-best --emb_dim 64 --seed [0,1,2,3,4]

# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --exp_id scaf-cov-try --seed [1,2,3,4]
# python main.py --dataset GOODHIV --domain size --shift concept --proto_w 0 -c_in feat  --exp_id siz_conc-best-124 --emb_dim 64 --seed [1,2,4]
# python main.py --dataset drugood_lbap_core_ec50_scaffold -c_in feat --emb_dim 64 --vrex_w 0 --simsiam_w 0 --cau_mix_w 0 --batch_size 16 --caus 0 --exp_id e-scaf-another_best --seed [0,1,2,3,4]
# python main.py --dataset drugood_lbap_core_ic50_aassay -c_in feat --emb_dim 128 --caus 0 --exp_id i-as-be-try --seed [0]
# python main.py --dataset GOODHIV --domain scaffold --shift covariate --batch_size 64 --num_prototype 10 --exp_id scaf-cov-1 --seed [1]

# python main.py --dataset GOODHIV --domain scaffold --shift covariate --dropout 0.5 --batch_size 64 --num_prototype 13 --seed [0]
# # python main.py --dataset GOODHIV --domain scaffold --shift covariate --cau_mix_w 0 --seed [0]
# # python main.py --dataset GOODHIV --domain scaffold --shift concept --cau_mix_w 0 --proto_w 0 --simsiam_w 0 --vrex_w 0 --size_pred_w 0 --seed [0]
# python main.py --dataset GOODHIV --domain scaffold --shift concept --cau_mix_w 0 --proto_w 0 --simsiam_w 0 --vrex_w 0 --caus 0 --seed [1,2]
# # python main.py --dataset GOODHIV --domain scaffold --shift concept --cau_mix_w 0 --proto_w 0 --simsiam_w 0 --vrex_w 0 --seed [0,1,2,3,4]
# python main.py --dataset GOODHIV --domain size --shift covariate --simsiam_w 0 --seed [0,1,2,3,4]
# python main.py --dataset GOODHIV --domain size --shift concept --proto_w 0 -c_in feat --emb_dim 64 --seed [0]
# python main.py --dataset GOODHIV --domain size --shift concept --proto_w 0 -c_in feat --emb_dim 64 --shuf_after_mix 1 --num_layers 3 --dropout 0.5  --seed [0]
# python main.py --dataset GOODHIV --domain size --shift concept --proto_w 0 --seed [0,1,2,3,4]

# python main.py --dataset GOODHIV --domain size --shift covariate --lr 1e-4 --num_prototype 10 --exp_id si_cova-try --seed [0]
# python main.py --dataset GOODHIV --domain size --shift covariate --num_prototype 10 --exp_id ori --seed [4]
# python main.py --dataset GOODHIV --domain size --shift concept --proto_w 0 -c_in feat --emb_dim 64 --exp_id siz_conc-best --seed [2]
# python main.py --dataset GOODHIV --domain size --shift concept --proto_w 0 --exp_id si_conc_another_best --seed [0,1,2,3,4]

# python main.py --dataset drugood_lbap_core_ic50_size -c_in feat --emb_dim 64 --num_layers 3

# python main.py --dataset drugood_lbap_core_ec50_assay --proto_w 0 --seed [0,1,2,3,4]
# python main.py --dataset drugood_lbap_core_ec50_scaffold -c_in feat --emb_dim 64 --vrex_w 0 --simsiam_w 0 --cau_mix_w 0 --seed [0,1,2,3,4]
# python main.py --dataset drugood_lbap_core_ec50_size -c_in feat --emb_dim 64 --shuf_after_mix 1 --num_layers 3 --dropout 0.5 --seed [0,1,2,3,4]
# python main.py --dataset drugood_lbap_core_ic50_assay -c_in feat --emb_dim 128 --seed [0,1,2,3,4]
# python main.py --dataset drugood_lbap_core_ic50_scaffold --cau_mix_w 0 --seed [4]
# python main.py --dataset drugood_lbap_core_ic50_size -c_in feat --emb_dim 64 --num_layers 3 --seed [0,1,2,3,4]
# >>
# python main.py --dataset drugood_lbap_core_ec50_scaffold -c_in feat --emb_dim 64 --vrex_w 0 --simsiam_w 0 --cau_mix_w 0 --batch_size 16 --seed [0,1,4]
# python main.py --dataset drugood_lbap_core_ec50_assay --proto_w 0 --seed [1,3,4]

