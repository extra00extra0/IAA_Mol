# !/bin/bash

# BACE
python main.py --dataset ogbg-molbace --subs_path ./preprocess/ogbg_molbace/substructure_stats_brics.json --dist_w 0 --size_pred_w 1 --cau_mix_w 0 --vrex_w 0 --simsiam_w 0 --epoch 15 --exp_id bace_0000 --seed [0]
python main.py --dataset ogbg-molbace --subs_path ./preprocess/ogbg_molbace/substructure_stats_brics.json --dist_w 0 --size_pred_w 1 --cau_mix_w 0 --vrex_w 0 --simsiam_w 0 --epoch 15 --exp_id bace_0000 --seed [0]
python main.py --dataset ogbg-molbace --subs_path ./preprocess/ogbg_molbace/substructure_stats_brics.json --dist_w 0 --size_pred_w 1 --cau_mix_w 0 --vrex_w 0 --simsiam_w 0 --epoch 15 --exp_id bace_0000 --seed [0]
python main.py --dataset ogbg-molbace --subs_path ./preprocess/ogbg_molbace/substructure_stats_brics.json --dist_w 0 --size_pred_w 1 --cau_mix_w 0 --vrex_w 0 --simsiam_w 0 --epoch 15 --exp_id bace_0000 --seed [0]
python main.py --dataset ogbg-molbace --subs_path ./preprocess/ogbg_molbace/substructure_stats_brics.json --dist_w 0 --size_pred_w 1 --cau_mix_w 0 --vrex_w 0 --simsiam_w 0 --epoch 15 --exp_id bace_0000 --seed [0]

# BBBP
# python main.py --dataset ogbg-molbbbp --subs_path ./preprocess/ogbg_molbbbp/substructure_stats_brics.json --dist 0 --cau_mix_w 0 --epoch 15 --exp_id bbbp_dist1_0 --seed [0]
# python main.py --dataset ogbg-molbbbp --subs_path ./preprocess/ogbg_molbbbp/substructure_stats_brics.json --dist 0 --cau_mix_w 0 --epoch 15 --exp_id bbbp_dist1_1 --seed [1]
# python main.py --dataset ogbg-molbbbp --subs_path ./preprocess/ogbg_molbbbp/substructure_stats_brics.json --dist 0 --cau_mix_w 0 --epoch 15 --exp_id bbbp_dist1_2 --seed [2]
# python main.py --dataset ogbg-molbbbp --subs_path ./preprocess/ogbg_molbbbp/substructure_stats_brics.json --dist 0 --cau_mix_w 0 --epoch 15 --exp_id bbbp_dist1_3 --seed [3]
# python main.py --dataset ogbg-molbbbp --subs_path ./preprocess/ogbg_molbbbp/substructure_stats_brics.json --dist 0 --cau_mix_w 0 --epoch 15 --exp_id bbbp_dist1_4 --seed [4]

