import warnings
warnings.filterwarnings("ignore", category=UserWarning)
from rdkit.Chem import BRICS
from DataLoading import pyg_moldataset
import argparse
import os
import pickle
import subprocess
from tqdm import tqdm


def get_result_dir():
    work_dir = os.path.abspath(os.path.dirname(__file__))
    result_dir = os.path.join(work_dir, '../preprocess')
    if not os.path.exists(result_dir):
        os.makedirs(result_dir)
    return result_dir


if __name__ == '__main__':
    parser = argparse.ArgumentParser('Preprocessing For Dataset')
    parser.add_argument(
        '--dataset', default='ogbg-molbace', type=str,
        help='the dataset to preprocess'
    )
    parser.add_argument(
        '--timeout', default=1000, type=int,
        help='maximal time to process a single molecule, count int seconds'
    )
    parser.add_argument(
        '--method', choices=['recap', 'brics'], default='brics',
        help='the method to decompose the molecule, brics or recap'
    )
    try:
        args = parser.parse_args()
    except:
        parser.print_help()
        exit(0)

    print(args)

    result_dir = get_result_dir()
    data_name = args.dataset.replace('-', '_')
    if not os.path.exists(os.path.join(result_dir, data_name)):
        os.mkdir(os.path.join(result_dir, data_name))
    smiles, dataset, label = pyg_moldataset(args.dataset)
    file_name = 'substructures.pkl' if args.method == 'brics' \
        else 'substructures_recap.pkl'
    file_name = os.path.join(result_dir, data_name, file_name)
    escapes = []
    with open(file_name, 'w') as Fout:
        for idx, smile in enumerate(tqdm(smiles)):
            try:
                subprocess.run([
                    'python', 'GetSubStruct.py', '--smile',
                    smile, '--method', args.method
                ], check=True, timeout=args.timeout, stdout=Fout)
            except subprocess.TimeoutExpired:
                escapes.append(idx)
                Fout.write(f'{smile}\t{str(set([smile]))}\n')

    if len(escapes) > 0:
        print('[INFO] the following molecules are processed unsuccessfully:')
        [print(smiles[x]) for x in escapes]

    substruct_list = []

    with open(file_name) as Fin:
        for lin in Fin:
            if len(lin) <= 1:
                continue
            lin = lin.strip().split('\t')
            assert len(lin) == 2, f'Invalid Line {lin}'
            assert type(eval(lin[1])) == set, f'Invalid value1 {lin[1]}'
            if len(eval(lin[1])) == 0:
                print(
                    f'[INFO] empty substruct find for {lin[0]},'
                    'consider itself as a substructure'
                )
                substruct_list.append(set([lin[0]]))
            else:
                substruct_list.append(eval(lin[1]))

    with open(file_name, 'wb') as Fout:
        pickle.dump(substruct_list, Fout)
        
    import json
    import ast
    from collections import defaultdict

    k_conf = 0.8

    labels_flat = list(label)
    labels_flat = [int(x) for x in labels_flat]
    assert len(labels_flat) == len(substruct_list), \
        f"标签数量 {len(labels_flat)} 与分子数量 {len(substruct_list)} 不一致"
    
    data_split_idx = dataset.get_idx_split()
    train_idx = data_split_idx['train']
    train_labels = [labels_flat[x] for x in train_idx]
    train_subs = [substruct_list[x] for x in train_idx]

    sub_stats = defaultdict(lambda: defaultdict(int))
    for subs, y in zip(train_subs, train_labels):
        if isinstance(subs, str):
            try:
                subs = ast.literal_eval(subs)
            except Exception:
                print("error:subs:", subs)
#                subs = {subs}

        subs = set(subs)

        for s in subs:
            sub_stats[s][y] += 1

    num_classes = 2

    sub_results = []
    for sub_smiles, cnt_dict in sub_stats.items():
        total_count = sum(cnt_dict.values())
        prob_list = []
        for c in range(num_classes):
            cnt = cnt_dict.get(c, 0)
            prob_list.append(cnt / total_count)

        confidence = 1.0 - (1.0 / total_count) ** k_conf

        sub_results.append({
            "smiles": sub_smiles,
            "label": prob_list,
            "confidence": confidence
        })
        
    json_name = f"substructure_stats_{args.method}.json"
    json_path = os.path.join(result_dir, data_name, json_name)

    with open(json_path, "w") as f_json:
        json.dump(sub_results, f_json, indent=2)

    print(f"[INFO] num of subs: {len(sub_results)} ,save in {json_path}")
