import torch
from torch_geometric.data import Data
import json
import numpy as np
from rdkit import Chem
from rdkit.Chem.Scaffolds.MurckoScaffold import MurckoScaffoldSmiles
def scaffold_split(dataset, frac_train=0.8, frac_valid=0.1, seed=42):
    """Deterministic scaffold split for MoleculeNet datasets (BACE/BBBP).
    """
    if Chem is None or MurckoScaffoldSmiles is None:
        raise ImportError("RDKit is required for scaffold split. Please install rdkit-pypi or rdkit.")

    from collections import defaultdict
    scaffolds = defaultdict(list)

    # Build scaffold buckets
    for i, data in enumerate(dataset):
        smiles = getattr(data, 'smiles', None)
        if smiles is None:
            # Fallback: try to convert from mol if available (rare)
            mol = getattr(data, 'mol', None)
            if mol is not None:
                smiles = Chem.MolToSmiles(mol, isomericSmiles=True)
        if smiles is None:
            # If no SMILES available, place into its own bucket by index
            scaffolds[f"__idx__{i}"] .append(i)
            continue

        try:
            scf = MurckoScaffoldSmiles(smiles=smiles, includeChirality=True)
        except Exception:
            scf = f"__invalid__{i}"
        scaffolds[scf].append(i)

    # Sort buckets by size (desc), then by scaffold key for determinism
    scaffold_sets = sorted(scaffolds.items(), key=lambda kv: (-len(kv[1]), kv[0]))

    n_total = len(dataset)
    n_train = int(n_total * float(frac_train))
    n_valid = int(n_total * float(frac_valid))
    cutoff_train = n_train
    cutoff_valid = n_train + n_valid

    train_idx, valid_idx, test_idx = [], [], []
    running = 0
    for _, idxs in scaffold_sets:
        if running < cutoff_train:
            train_idx += idxs
        elif running < cutoff_valid:
            valid_idx += idxs
        else:
            test_idx += idxs
        running += len(idxs)

    # Ensure determinism with a fixed order inside each split
    rng = np.random.default_rng(int(seed))
    train_idx = list(train_idx)
    valid_idx = list(valid_idx)
    test_idx  = list(test_idx)
    
    return train_idx, valid_idx, test_idx

def load_sub_info(json_path):
    """
    {
      "k": 0.8,
      "samples": [
        {
          "smiles": "...",
          "label": [p0, p1],
          "confidence": c
        },
        ...
      ]
    }
    return dict[smiles] = (label_list, confidence)
    """
    with open(json_path, 'r') as f:
        data = json.load(f)

    table = {}
    # for item in data["samples"]:
    for item in data:
        smi = item["smiles"]
        label = item["label"]          
        conf = item["confidence"]      
        table[smi] = (label, conf)
    return table

def dgl_to_pyg(dgl_graph):
    x = dgl_graph.ndata['x']            

    src, dst = dgl_graph.edges()     
    edge_index = torch.stack([src, dst], dim=0)

    edge_attr = dgl_graph.edata['x']    

    pyg_data = Data(
        x=x,
        edge_index=edge_index,
        edge_attr=edge_attr
    )

    return pyg_data