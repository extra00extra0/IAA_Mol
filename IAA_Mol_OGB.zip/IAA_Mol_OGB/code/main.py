# Dataset: BACE BBBP

import argparse
import os
import os.path as osp
from copy import deepcopy
from datetime import datetime
import pickle
import ast
import numpy as np
import torch
import torch.nn.functional as F
from drugood.datasets import build_dataset
from drugood.utils.smile_to_dgl import smile2graph
from mmcv import Config
from ogb.graphproppred import Evaluator, PygGraphPropPredDataset
from sklearn.metrics import matthews_corrcoef
from torch_geometric.data import DataLoader
from torch_geometric.datasets import TUDataset
from torch_geometric.nn import global_mean_pool
from tqdm import tqdm
import torch.nn as nn
from GOOD.data.good_datasets.good_hiv import GOODHIV
from DataLoading import pyg_molsubdataset
import warnings
warnings.filterwarnings("ignore")
from datasets.drugood_dataset import DrugOOD
from datasets.graphss2_dataset import get_dataloader_per, get_dataset
from datasets.mnistsp_dataset import CMNIST75sp
from datasets.spmotif_dataset import SPMotif
from models.iaa_mol import  iaa_mol
from models.losses import get_contrast_loss, get_irm_loss
from utils.logger import Logger
from utils.subs import load_sub_info, scaffold_split
from utils.util import args_print, set_seed, sigmoid
# from drawer import draw_tsne
import json
from torch_geometric.data import Data, Batch
from pretrain import pretrain_cls
from torch.utils.data import Subset
try:
    from rdkit import Chem
    from rdkit.Chem.Scaffolds.MurckoScaffold import MurckoScaffoldSmiles
except Exception:
    Chem = None
    MurckoScaffoldSmiles = None

def mix_criterion(input, target, size_average=True):
    """Categorical cross-entropy with logits input and one-hot target"""
    l = -(target * torch.log(F.softmax(input, dim=1) + 1e-10)).sum(1)
    if size_average:
        l = l.mean()
    else:
        l = l.sum()
    return l

@torch.no_grad()
def eval_model(model, device, loader, evaluator, eval_metric='acc', save_pred=False,c_pred=False,c_in="raw",train=False):
    model.eval()
    y_true = []
    y_pred = []
    S_rep=None
    S_y=None

    for batch in loader:
        if train:
            batch = batch[1]
        batch = batch.to(device)
        batch = batch.to(device)
        if batch.x.shape[0] == 1:
            pass
        else:
            with torch.no_grad():
                batch.x = batch.x.float()
                batch.y  = batch.y.reshape(-1)
                if c_in=="raw":
                    pred, batch_rep = model.classifier(batch,get_rep=True)
                else:
                    pred, batch_rep = model.get_eval_pred(batch,get_rep=True)
            if S_rep is None:
                S_rep=batch_rep.detach().cpu().numpy()
            else:
                S_rep = np.concatenate((S_rep,batch_rep.detach().cpu().numpy()), axis=0)

            if S_y is None:
                S_y=batch.y.detach().cpu().numpy()
            else:
                S_y=np.concatenate((S_y, batch.y.detach().cpu().numpy()),axis=0)

            is_labeled = batch.y == batch.y
            if eval_metric == 'acc':
                if len(batch.y.size()) == len(batch.y.size()):
                    y_true.append(batch.y.view(-1, 1).detach().cpu())
                    y_pred.append(torch.argmax(pred.detach(), dim=1).view(-1, 1).cpu())
                else:
                    y_true.append(batch.y.unsqueeze(-1).detach().cpu())
                    y_pred.append(pred.argmax(-1).unsqueeze(-1).detach().cpu())
            elif eval_metric == 'rocauc':
                pred = F.softmax(pred, dim=-1)[:, 1].unsqueeze(-1)
                if len(batch.y.size()) == len(batch.y.size()):
                    y_true.append(batch.y.view(-1, 1).detach().cpu())
                    y_pred.append(pred.detach().view(-1, 1).cpu())
                else:
                    y_true.append(batch.y.unsqueeze(-1).detach().cpu())
                    y_pred.append(pred.unsqueeze(-1).detach().cpu())
            elif eval_metric == 'mat':
                y_true.append(batch.y.unsqueeze(-1).detach().cpu())
                y_pred.append(pred.argmax(-1).unsqueeze(-1).detach().cpu())
            elif eval_metric == 'ap':
                y_true.append(batch.y.view(pred.shape).detach().cpu())
                y_pred.append(pred.detach().cpu())
            else:
                if is_labeled.size() != pred.size():
                    with torch.no_grad():
                        # pred, rep = model(batch, return_data="rep")
                        pred, rep = model.get_eval_pred(batch, get_rep=True)
                        print(rep.size())
                    print(batch)
                    print(global_mean_pool(batch.x, batch.batch).size())
                    print(pred.shape)
                    print(batch.y.size())
                    print(sum(is_labeled))
                    print(batch.y)
                batch.y = batch.y[is_labeled]
                pred = pred[is_labeled]
                y_true.append(batch.y.view(pred.shape).unsqueeze(-1).detach().cpu())
                y_pred.append(pred.detach().unsqueeze(-1).cpu())

    y_true = torch.cat(y_true, dim=0).numpy()
    y_pred = torch.cat(y_pred, dim=0).numpy()

    if eval_metric == 'mat':
        res_metric = matthews_corrcoef(y_true, y_pred)
    else:
        input_dict = {"y_true": y_true, "y_pred": y_pred}
        res_metric = evaluator.eval(input_dict)[eval_metric]

    if save_pred:
        return res_metric, y_pred,S_rep,S_y
    else:
        return res_metric,S_rep,S_y


def main():
    parser = argparse.ArgumentParser(description='Causality Inspired Invariant Graph LeArning')
    parser.add_argument('--device', default=0, type=int, help='cuda device')
    parser.add_argument('--root', default='./data', type=str, help='directory for datasets.')
    parser.add_argument('--dataset', default='ogbg-molbace', type=str)
    parser.add_argument('--subs_path', default='./preprocess/ogbg_molbace/substructure_stats_brics.json')
    parser.add_argument('--bias', default='0.5', type=str, help='select bias extend')
    parser.add_argument('--feature', type=str, default="full", help='full feature or simple feature')
    parser.add_argument(
        '--decomp_method', choices=['brics', 'recap'], default='brics',
        help='the method to decompose the molecules into substructures'
    )
    parser.add_argument('--eps', type=float, default=0.95)
    # training config
    parser.add_argument('--batch_size', default=32, type=int, help='batch size')
    parser.add_argument('--epoch', default=15, type=int, help='training iterations')
    parser.add_argument('--lr', default=0.001, type=float, help='learning rate for the predictor')
    parser.add_argument('--seed', nargs='?', default='[0]', help='random seed')
    parser.add_argument('--pretrain', default=20, type=int, help='pretrain epoch before early stopping')

    # model config
    parser.add_argument('--emb_dim', default=64, type=int)
    
    # emb dim of classifier
    parser.add_argument('-c_dim', '--classifier_emb_dim', default=64, type=int)
    # inputs of classifier
    # raw:  raw feat
    # feat: hidden feat from featurizer 
    parser.add_argument('-c_in', '--classifier_input_feat', default='raw', type=str)
    parser.add_argument('--model', default='gin', type=str)
    parser.add_argument('--pooling', default='mean', type=str)
    parser.add_argument('--num_layers', default=2, type=int)
    parser.add_argument('--num_workers', default=4, type=int)
    parser.add_argument('--early_stopping', default=5, type=int)
    parser.add_argument('--dropout', default=0, type=float)
    parser.add_argument('--virtual_node', action='store_true')
    parser.add_argument('--eval_metric',
                        default='auc',
                        type=str,
                        help='specify a particular eval metric, e.g., mat for MatthewsCoef')
    
    parser.add_argument('--domain', default="scaffold", type=str)
    parser.add_argument('--shift', default="covariate", type=str)



    # weight

    parser.add_argument('--c_pred', default=0.0, type=float, help='use casual part to predict')
    parser.add_argument('--s_pred', default=0.0, type=float, help='use spu part to predict')
    parser.add_argument('--caus', default=1, type=float, help='add casual manifold mixup')
    parser.add_argument('--mix', default=0, type=float)
    parser.add_argument('--r', default=0.7, type=float, help='selected ratio')
    parser.add_argument('--irm_w', default=1, type=float)
    parser.add_argument('--vrex_w', default=1, type=float)
    parser.add_argument('--size_pred_w',default=1, type=float)
    parser.add_argument('--shuf_pred_w',default=1, type=float)
    parser.add_argument('--cau_mix_w',default=1, type=float)
    parser.add_argument('--simsiam_w',default=1, type=float)
    parser.add_argument('--dist_w', default=1, type = float)
    
    
    parser.add_argument('--shuf_after_mix', default=0, type=int)
    parser.add_argument('--pretrain_epoch', default=0, type=int)
    parser.add_argument('--exp_id', default="0", type=str)
    parser.add_argument('--num_prototype', default=7, type=int)
    

    # misc
    parser.add_argument('--no_tqdm', action='store_true')
    parser.add_argument('--commit', default='', type=str, help='experiment name')
    parser.add_argument('--save_model', action='store_true')  # save pred to ./pred if not empty

    parser.add_argument('--temp', default=1, type=float)

    args = parser.parse_args()
    erm_model = None  # used to obtain pesudo labels for CNC sampling in contrastive loss
    # log
    datetime_now = datetime.now().strftime("%Y%m%d-%H%M%S")
    datetime_now = datetime_now[-5:]
    #TODO: debug tesorboard

    args.seed = eval(args.seed)

    if args.device<=7:
        device = torch.device("cuda:" + str(args.device)) if torch.cuda.is_available() else torch.device("cpu")
    else:
        device = torch.device("cpu")
    print(device)
    def ce_loss(a, b, reduction='mean'):
        return F.cross_entropy(a, b, reduction=reduction)

    criterion = ce_loss
    eval_metric = 'acc' if len(args.eval_metric) == 0 else args.eval_metric
    edge_dim = -1.
    
    subs_info = load_sub_info(args.subs_path)

    if args.dataset.lower() in ['ogbg-molbace','ogbg-molbbbp']:
        from torch_geometric.datasets import MoleculeNet
        # Load dataset
        if args.dataset.lower() == 'ogbg-molbace':
            mol_dataset = MoleculeNet(root='data/', name='bace')
        elif args.dataset.lower() == 'ogbg-molbbbp':
            mol_dataset = MoleculeNet(root='data/', name='bbbp')
        train_idx, valid_idx, test_idx = scaffold_split(mol_dataset, frac_train=0.8, frac_valid=0.1, seed=0)
        total_smiles, total_subs, dataset = pyg_molsubdataset(
            args.dataset, args.decomp_method
        )
        train_subs = [str(total_subs[x]) for x in train_idx]

        train_dataset = dataset[train_idx]
        valid_dataset = dataset[valid_idx]
        test_dataset = dataset[test_idx]
        train_loader = DataLoader(list(zip(train_subs,train_dataset)), batch_size=args.batch_size, shuffle=True, drop_last=True)
        valid_loader = DataLoader(valid_dataset, batch_size=args.batch_size, shuffle=False)
        test_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)
        input_dim = 9
        edge_dim = 3
        num_classes = 2
        evaluator = Evaluator('ogbg-molhiv')
        eval_metric = args.eval_metric = 'rocauc'
    
    elif args.dataset.lower() in ['goodhiv']:
        dataset, _ = GOODHIV.load('data/', domain=args.domain, shift=args.shift, generate=False)
        train_loader=DataLoader(dataset["train"],args.batch_size,shuffle=True)
        valid_loader=DataLoader(dataset["val"],args.batch_size,shuffle=False)
        test_loader=DataLoader(dataset["test"],args.batch_size,shuffle=False)
        input_dim = 9
        num_classes = 2
        evaluator = Evaluator('ogbg-molhiv')
        eval_metric = 'rocauc'

    else:
        raise Exception("Invalid dataset name")

    
#    dataset_name = args.dataset.removesuffix("drugood_lbap_core")
    datetime_day = datetime.now().strftime("%Y%m%d-%H%M%S")
    datetime_day = datetime_day[4:8]
    dataset_name = args.dataset[-6:]
    experiment_name1 = f'{dataset_name}-{datetime_day}'
    experiment_name2 = f'{args.exp_id}-{datetime_now}'
    exp_dir = os.path.join('./logs/', experiment_name1, experiment_name2)
    os.makedirs(exp_dir, exist_ok=True)
    logger = Logger.init_logger(filename=exp_dir + '/log.log')
    args_print(args, logger)
    logger.info(f"Using criterion {criterion}")

    logger.info(f"# Train: {len(train_loader.dataset)}  #Val: {len(valid_loader.dataset)} #Test: {len(test_loader.dataset)} ")
    best_weights = None

    for seed in args.seed:
        set_seed(seed)
        
        model = iaa_mol(ratio=args.r,
                        input_dim=input_dim,
                        edge_dim=edge_dim,
                        out_dim=num_classes,
                        gnn_type=args.model,
                        num_layers=args.num_layers,
                        emb_dim=args.emb_dim,
                        drop_ratio=args.dropout,
                        graph_pooling=args.pooling,
                        virtual_node=args.virtual_node,
                        c_dim=args.classifier_emb_dim,
                        c_in=args.classifier_input_feat,
                        eps=args.eps).to(device)
        
        if args.classifier_input_feat=="raw":
            pretrain_cls(model.classifier, args, train_loader, valid_loader, test_loader, exp_dir, device, criterion, c_in="raw")
            if args.pretrain_epoch >0:
                cls_path = os.path.join(exp_dir, "cls.pth")
                model.classifier.load_state_dict(torch.load(cls_path, map_location=device))
        else:
            pretrain_cls(model, args, train_loader, valid_loader, test_loader, exp_dir, device, criterion, c_in="feat")
            if args.pretrain_epoch >0:
                cls_path = os.path.join(exp_dir, "cls.pth")
                model.load_state_dict(torch.load(cls_path, map_location=device))
        
        model_optimizer = torch.optim.Adam(list(model.parameters()), lr=args.lr)
        
        last_train_acc, last_test_acc, last_val_acc = 0, 0, 0
        train_auc_list, val_auc_list, test_auc_list = [], [], []
        cnt = 0
        for epoch in range(args.epoch):
            
            epoch_feature_size=np.empty((0,args.emb_dim))
            epoch_size_y=np.empty((0))
            model.train()
            torch.autograd.set_detect_anomaly(True)
            for subs, graph in tqdm(train_loader):
                dynamic_w = sigmoid(10*(epoch/args.epoch-0.5))
                graph.to(device)
                graph.x = graph.x.float().to(device)
                graph.y = graph.y.reshape(-1)
                # ignore nan targets
                # https://github.com/snap-stanford/ogb/blob/master/examples/graphproppred/mol/main_pyg.py
                is_labeled = graph.y == graph.y
                #is_labeled = is_labeled.reshape(-1)
                
                # select sub for each graph
                best_score_per_graph = []
                num_graphs = graph.num_graphs
                for g_idx in range(num_graphs):
                    subs_list = subs[g_idx]
                    subs_list = ast.literal_eval(subs_list)
                    y_i = int(graph.y[g_idx].item())

                    best_score = -1.0
                    for smi in subs_list:
                        info = subs_info.get(smi, None)
                        if info is None:
                            # print("miss::", smi)
                            label_vec = [0.0,0.0]
                            conf=0.0
                        else:
                            label_vec, conf = info
                        label_val = label_vec[y_i]
                        score = label_val * conf

                        if score > best_score:
                            best_score = score

                    best_score_per_graph.append(best_score)
                
                # sub smiles-> pyg data
                # sub_data_list = []
                # from ogb.utils.mol import smiles2graph
                # for smi, score in zip(best_sub_smiles_per_graph, best_score_per_graph):
                #     if smi is None:
                #         print("miss skip")
                #         continue
                    
                #     dict = smiles2graph(smi)
                #     x = torch.tensor(dict['node_feat']).float()
                #     edge_index = torch.tensor(dict['edge_index']).long()
                #     edge_attr = torch.tensor(dict['edge_feat']).float()

                #     sub_data = Data(
                #         x = x,
                #         edge_index = edge_index,
                #         edge_attr = edge_attr
                #     )
                #     sub_data_list.append(sub_data)

                # if len(sub_data_list) > 0:
                #     sub_batch = Batch.from_data_list(sub_data_list).to(device)
                    

#                if args.caus:
                if True:
                    mixup_x,mixup_y,ori_pred, cau_mix_pred, cau_mix_y, size_pred, simsiam_loss, size_rep, batch_rep, dist_loss = model(graph, subs,subs_info,return_data="feat",casual_mix=True,num_label=num_classes, shuf_after_mix=args.shuf_after_mix,
                        temp=args.temp)
                    cau_loss = mix_criterion(mixup_x[is_labeled],mixup_y[is_labeled])

                else:
                    ori_pred,mix_pred,new_y,c_pred = model(graph,return_data="feat")
    
                cau_mix_loss = mix_criterion(cau_mix_pred[is_labeled], cau_mix_y[is_labeled])
                graph.y = graph.y.long()
                ori_pred_loss = criterion(ori_pred[is_labeled], graph.y[is_labeled], reduction='none')

                size_pred_loss = criterion(size_pred[is_labeled], graph.y[is_labeled], reduction='none')

                vrex_loss = torch.var(torch.FloatTensor([ori_pred_loss.mean(), size_pred_loss.mean(), cau_mix_loss.mean()]).to(device))
                
                sub_score = torch.tensor(best_score_per_graph,  dtype=torch.float, device=device)
                dynamic_dist_w = 1-dynamic_w
                dist_loss_w = sub_score * dist_loss

                

                pred_loss =  ori_pred_loss.mean() \
                            + args.caus * cau_loss.mean() * dynamic_w \
                            + args.cau_mix_w * cau_mix_loss.mean() * dynamic_w \
                            + args.size_pred_w * size_pred_loss.mean() \
                            + args.simsiam_w * simsiam_loss * dynamic_w \
                            + args.vrex_w * vrex_loss * dynamic_w\
                            + args.dist_w * dist_loss_w.mean() * dynamic_dist_w
                   
                # compile losses
                model_optimizer.zero_grad()
                pred_loss.backward()
                model_optimizer.step()

                y_b=graph.y[is_labeled].reshape(-1).cpu().numpy()
                size_rep_b=size_rep[is_labeled].detach().cpu().numpy()

                epoch_feature_size=np.concatenate((epoch_feature_size,size_rep_b),axis=0)
                epoch_size_y=np.concatenate((epoch_size_y,y_b),axis=0)


            # cos = nn.CosineSimilarity(dim=1, eps=1e-6)
            # epoch_proto = torch.tensor(0.0, device=device)
            # cnt = 0

            # for i in range(num_classes):
            #     feats = feat_dict[i]
            #     prototypes = prototype_dict[i]
    
            #     for feat_tensor in feats:
            #         for feat in feat_tensor:
            #             feat = feat.unsqueeze(0)
            #             sims = [cos(feat, proto) for proto in prototypes]
            #             sims = torch.stack(sims)
            #             best_idx = torch.argmax(sims)
            #             epoch_proto += (1 - sims[best_idx]).item()
            #             cnt += 1
            # print("*" * 50)
            # print((epoch_proto / cnt).item())

            print(dynamic_w, dynamic_dist_w)
            model.eval()
            train_acc, train_feature, train_y = eval_model(model, device, train_loader, evaluator, eval_metric=eval_metric,c_pred=args.c_pred,c_in=args.classifier_input_feat,train=True)
            val_acc, valid_feature, valid_y = eval_model(model, device, valid_loader, evaluator, eval_metric=eval_metric,c_pred=args.c_pred, c_in=args.classifier_input_feat)
            test_acc,_,_ = eval_model(model,
                                  device,
                                  test_loader,
                                  evaluator,
                                  eval_metric=eval_metric,c_pred=args.c_pred, c_in=args.classifier_input_feat)
            if val_acc <= last_val_acc:
                # select model according to the validation acc,
                #                  after the pretraining stage
                cnt += epoch >= args.pretrain
            elif epoch>2:
                cnt = (cnt + int(epoch >= args.pretrain)) if last_val_acc == 1.0 else 0
                last_train_acc = train_acc
                train_auc_list.append(last_train_acc)
                last_val_acc = val_acc
                val_auc_list.append(last_val_acc)
                last_test_acc = test_acc
                test_auc_list.append(last_test_acc)
                train_feature_size=epoch_feature_size
                size_y = epoch_size_y
                train_feature_batch = train_feature
                train_y_batch = train_y
                valid_feature_batch = valid_feature
                valid_y_batch = valid_y
 
                if args.save_model:
                    best_weights = deepcopy(model.state_dict())
            if epoch >= args.pretrain and cnt >= args.early_stopping:
                logger.info("Early Stopping")
                logger.info("+" * 50)
                logger.info("Last: Test_ACC: {:.4f} Train_ACC:{:.4f} Val_ACC:{:.4f} ".format(
                    last_test_acc, last_train_acc, last_val_acc))
                break

            print("      [{:3d}/{:d}]".format(epoch, args.epoch) +
                        "\n       train_ACC: {:.4f} / {:.4f}"
                        "\n       valid_ACC: {:.4f} / {:.4f}"
                        "\n       tests_ACC: {:.4f} / {:.4f}\n".format(
                            train_acc, last_train_acc,
                            val_acc, last_val_acc,
                            test_acc, last_test_acc))

        # draw_tsne(train_feature_batch, valid_feature_batch, train_y_batch, valid_y_batch, args.exp_id ,logger, args.emb_dim)
        
        logger.info("test_score:{:.4f}".format(last_test_acc))
        logger.info("best_test_score{:.4f}".format(max(test_auc_list)))
   
    if args.save_model:
        print("Saving best weights..")
        # model_path = os.path.join('save_my', 'ciga_'+args.dataset) + str(args.r)+'_' +datetime_now+ ".pt"
        model_path = os.path.join('save_my', args.dataset) + str(args.r)+'_' +datetime_now+ ".pt"
        for k, v in best_weights.items():
            best_weights[k] = v.cpu()
        torch.save(best_weights, model_path)
        print("Done..")

    print("\n\n\n")
    torch.cuda.empty_cache()


if __name__ == "__main__":
    main()
